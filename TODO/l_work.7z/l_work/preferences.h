//
// Created by WiskiW on 12.05.2017.
//

#ifndef L_WORK_PREFERENCES_H
#define L_WORK_PREFERENCES_H

#include <console_io_lib/console_io_lib.h>

const extern Color EXCEPTION_COLOR = LightRed;
const extern Color WARNING_COLOR = Yellow;
const extern Color OK_COLOR = LightGreen;
const extern Color MSG_COLOR = LightGray;
const extern Color INPUT_COLOR = White;

#endif //L_WORK_PREFERENCES_H
