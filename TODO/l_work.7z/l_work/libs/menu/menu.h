//
// Created by WiskiW on 30.04.2017.
//

#ifndef OAP_MENU_H
#define OAP_MENU_H


int printMainMenu();

int printDatabaseMenu();

int confirmMenu();

int printItemMenu();

int printListMenu();

int printFieldMenu();

int printDirMenu();

#endif //OAP_MENU_H
