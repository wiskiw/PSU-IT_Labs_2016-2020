#!/bin/bash
# chmod u+x task6.sh

find "$1" -type f -executable ! -name "$0" -exec {} \;