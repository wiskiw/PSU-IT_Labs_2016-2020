#!/bin/bash
# chmod u+x task4.sh
# ./task4.sh ~/Desktop/univer/osisp/lab1 ~/Desktop/univer/osisp/lab2
path1=$1
path2=$2
cd $path1
mv *[0-9]*[0-9]*[0-9]* $path2 
cd $path2
ls *[0-9]*[0-9]*[0-9]*
echo "Done!"
# $ tr -dc A-Za-z0-9_ < /dev/urandom | head -c 10 | xargs