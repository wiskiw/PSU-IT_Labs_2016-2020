#include <stdio.h>
//gcc -o task7 task7.c
int main() {
 printf("Konstantin Scherbitsky\n");
 return 0;
}