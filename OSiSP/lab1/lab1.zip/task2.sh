#!/bin/bash
# ./task2.sh ~/Desktop/univer/osisp *.txt
# chmod u+x task2.sh
FIND_CMD='find '$1' -name '$2
echo 'files to remove: '
$FIND_CMD 
#$FIND_CMD '-delete'
