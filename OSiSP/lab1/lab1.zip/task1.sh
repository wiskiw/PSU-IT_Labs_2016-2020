#!/bin/bash
# chmod u+x task1-1.sh
path=$1
filename=$2
cd $path
ls *$filename 
echo "Done!"


