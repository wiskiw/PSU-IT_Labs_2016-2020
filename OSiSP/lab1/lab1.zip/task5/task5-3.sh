#!/bin/bash
# chmod u+x task5-3.sh
let "mul = $1*$2*$3"
echo "$1*$2*$3 = $mul"
