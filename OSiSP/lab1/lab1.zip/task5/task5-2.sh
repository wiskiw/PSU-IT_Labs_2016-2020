#!/bin/bash
# chmod u+x task5-2.sh
let "dif = $1-$2-$3"
echo "$1-$2-$3 = $dif"
