#!/bin/bash
# chmod u+x task5-4.sh
let "sum = $1+$2+$3"
echo "$1+$2+$3 = $sum"
