#!/bin/bash
# chmod u+x task5-1.sh

if [[ $1 == 1 ]]; then # сумма
 ./task5-4.sh $2 $3 $4
fi
if [[ $1 == 2 ]]; then # вычитание
 ./task5-2.sh $2 $3 $4 
fi
if [[ $1 == 3 ]]; then # умножение
 ./task5-3.sh $2 $3 $4 
fi

exit 0
