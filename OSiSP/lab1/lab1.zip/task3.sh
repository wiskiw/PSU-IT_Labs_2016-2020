#!/bin/bash
# chmod u+x task3.sh
#./task3.sh .txt ~/Desktop/univer/osisp/lab2/ ~/Desktop/univer/osisp/lab3/

find $1 -name *$2 -print0|xargs --null cp --parents -t $3
find $1 -name *$2 -print0|xargs --null cp --parents -t $4  
echo "Done!"