#include <iostream>
#include <cstdio>
#include <cstdarg>
#include <cstdlib>


double fSum(int n, ...) {
    // n - число параметров переданных в функцию
    double srednee = 0; // среднее по всем параметрам
    double sum = 0;
    double t = 0; // доп. переменная
    va_list args; // переменная(список), который хранит все параметры переданные в эту функцию. пуст

    // находим среднее
    va_start(args, n); // заполняем список args, неопределенными параметрами, переданными в эту функцию
    for (int i = 0; i < n; i++) {
        t = va_arg(args, double); // получает следующее значение параметра типа double
        srednee = srednee + t;
    }
    srednee = srednee / n;
    printf("Srednee: %lf\n", srednee);
    va_end(args); // завершаем работу с неопределенными параметрами


    // подсчет суммы
    va_start(args, n); // сново заполняем список args, неопределенными параметрами, переданными в эту функцию
    for (int i = 0; i < n; i++) {
        t = va_arg(args, double); // получает следующее значение параметра типа double
        if (t > srednee) {
            // если следующее значение больше среднего значения всех параметров
            sum = sum + t;
        }
    }
    va_end(args); // завершаем работу с неопределенными параметрами

    return sum;
}


int main() {

    double sum = fSum(5, 11.1, 12.3, -13.05, 0.37, 15.21);
    // первый параметр должен быть равен числу последующих параметров
    // в данном случает n=5

    printf("SUM: %lf\n", sum);
    system("pause");
}

