fun main(args: Array<String>) {

    val collection = TransportCollection()
    collection.addCar()
    collection.addExpress()

    println(collection)

    collection.searchForCar()

}


