package sha

interface SHA1 {

    fun make(str: String): String
}