package com.psuteam.goodbooze.networking.endpoint.request

import com.psuteam.goodbooze.app.App
import com.psuteam.goodbooze.networking.endpoint.EndpointRequest
import com.psuteam.goodbooze.networking.proxy.Proxy
import org.json.JSONObject

class EditProfileRequest(
    private val id: String,
    private val name: String? = null,
    private val email: String? = null,
    private val bio: String? = null,
    private val imageId: String? = null
) : EndpointRequest<Boolean>() {

    companion object {
    }

    override fun setup(app: App) {
        super.setup(app)

        params.apply {
            put("id", id)
            put("name", name)
            put("email", email)
            put("bio", bio)
            put("imageId", imageId)
        }
    }

    override fun getMethodName(): String = "editProfile"

    override fun getMethod(): Proxy.Method = Proxy.Method.GET

    override fun parseResponse(data: JSONObject): Boolean = true

}