package com.psuteam.goodbooze.ui

import android.content.Intent
import android.os.Bundle
import android.view.MenuItem
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GravityCompat
import androidx.navigation.NavController
import androidx.navigation.Navigation.findNavController
import com.google.android.material.navigation.NavigationView
import com.psuteam.goodbooze.R
import com.psuteam.goodbooze.app.App
import com.psuteam.goodbooze.app.logger.LoggerFactory
import com.psuteam.goodbooze.app.utils.UiUtils
import com.psuteam.goodbooze.data.model.LoggedInUser
import com.psuteam.goodbooze.ui.feed.FeedFragmentDirections
import kotlinx.android.synthetic.main.activity_logged_in.*

/**
 * Activity-контейнер для авторизованной части приложения
 */
class LoggedInActivity : AppCompatActivity(), LoggedInFragmentContainer, NavigationView.OnNavigationItemSelectedListener {

    companion object {
        private val LOGGER = LoggerFactory.getLogger(LoggedInActivity::class.java)
        const val ARG_KEY_SHOULD_REFRESH_FRAGMENT = "shouldRefreshFragment"
    }

    private lateinit var app: App
    private lateinit var navController: NavController
    private lateinit var actionBarDrawerToggle: ActionBarDrawerToggle

    private lateinit var screenUiController: ScreenUiController
    private var loggedInUser: LoggedInUser? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_logged_in)

        app = application as App

        navController = findNavController(this, R.id.navHostFragment)
        navController.addOnDestinationChangedListener { controller, destination, arguments ->
            UiUtils.hideKeyboard(this, window.decorView)

            initLoggedInUser()

            setSupportActionBar(toolbar)

            actionBarDrawerToggle = ActionBarDrawerToggle(
                this,
                drawerLayout,
                toolbar,
                R.string.activity_root_drawer_open,
                R.string.activity_root_drawer_close
            )
            drawerLayout.addDrawerListener(actionBarDrawerToggle)
            navView.menu.clear()
            navView.inflateMenu(getDrawerMenu())
            navView.setNavigationItemSelectedListener(this)

            screenUiController = ScreenUiController(supportActionBar!!, drawerLayout, navView.getHeaderView(0))

        }
    }

    override fun onPostCreate(savedInstanceState: Bundle?) {
        super.onPostCreate(savedInstanceState)
        actionBarDrawerToggle.syncState()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)

        val shouldRefreshFragment = intent.getBooleanExtra(ARG_KEY_SHOULD_REFRESH_FRAGMENT, false)
        if (shouldRefreshFragment) {
            refreshFragment()
        }
    }

    private fun getDrawerMenu(): Int {
        return when (loggedInUser?.userRole) {
            LoggedInUser.UserRole.MODERATOR -> R.menu.activity_root_drawer_moderator
            else -> R.menu.activity_root_drawer
        }
    }

    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        loggedInUser?.let { loggedInUser ->
            return when (item.itemId) {
                R.id.rootDrawerProfile -> {
                    val action = FeedFragmentDirections.actionFeedFragmentToEditProfileFragment(loggedInUser.id)
                    navController.navigate(action)
                    true
                }
                R.id.rootDrawerLogout -> {
                    logout()
                    true
                }
                R.id.rootDrawerCreateProduct -> {
                    navController.navigate(R.id.action_feedFragment_to_createProductFragment)
                    true
                }
                R.id.rootDrawerModerFeed -> {
                    navController.navigate(R.id.action_feedFragment_to_moderatorFeedFragment)
                    true
                }
                else -> false
            }
        }

        return false
    }

    override fun onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START)

        } else {
            if (!navController.popBackStack()) {
                super.onBackPressed()
            }
        }
    }

    private fun initLoggedInUser() {
        val storageUser = app.dataStorageProvider.userStorage.readLoggedInUser()

        if (storageUser?.getTokens()?.isValid() == true) {
            this.loggedInUser = storageUser

        } else {
            NavUtils.goToAuthActivity(navController)

//             Finish is required to prevent attaching fragment
            finish()
        }
    }

    private fun refreshFragment() {
        val navigationFragmentManager = navHostFragment.childFragmentManager

        val currentFragment = navigationFragmentManager.fragments.firstOrNull()
        if (currentFragment != null) {
            LOGGER.debug("Refreshing current fragment '$currentFragment' ...")
            navigationFragmentManager.beginTransaction().apply {
                detach(currentFragment)
                attach(currentFragment)
                commit()
            }
        } else {
            throw IllegalStateException("NavHostFragment doesn't contains any fragments!")
        }
    }

    private fun logout() {
        app.dataStorageProvider.userStorage.deleteUserCredits()
        NavUtils.goToAuthActivity(navController)
        finish()
    }

    override fun getScreenUiController(): ScreenUiController = screenUiController

    override fun getLoggedInUser(): LoggedInUser = loggedInUser!!

}
