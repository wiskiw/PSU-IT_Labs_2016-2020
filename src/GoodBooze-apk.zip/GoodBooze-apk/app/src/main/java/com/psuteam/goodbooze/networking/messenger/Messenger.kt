package com.psuteam.goodbooze.networking.messenger


/**
 * Describe a "person", who send a request to server
 */
interface Messenger<out R : Any> {

    suspend fun send(): MessageResult<R>

}