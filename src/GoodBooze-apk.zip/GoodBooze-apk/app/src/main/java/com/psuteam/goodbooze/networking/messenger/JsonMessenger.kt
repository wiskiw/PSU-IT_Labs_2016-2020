package com.psuteam.goodbooze.networking.messenger

import com.psuteam.goodbooze.app.App
import com.psuteam.goodbooze.networking.proxy.Proxy
import com.psuteam.goodbooze.networking.proxy.ProxyException
import com.psuteam.goodbooze.networking.proxy.ProxyRequest
import com.psuteam.goodbooze.networking.proxy.ProxyResult
import org.json.JSONObject
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine

/**
 * Messenger implementation to send JSON [request] to a server via [proxy].
 */
open class JsonMessenger<out R : Any>(
    app: App,
    private val proxy: Proxy<JSONObject>,
    private val request: ProxyRequest<JSONObject, R>
) : Messenger<R> {

    companion object {
        private const val HTTP_UNAUTHORIZED = 401
    }

    init {
        request.setup(app)
    }

    override suspend fun send(): MessageResult<R> {
        val proxyResult = proxy.send(
            request.getMethod(),
            request.getUrlMethod(),
            request.headers,
            request.params
        )

        return suspendCoroutine { cont ->
            when (proxyResult) {
                is ProxyResult.Success -> {
                    cont.resume(onProxySuccess(proxyResult.code, proxyResult.data))
                }
                is ProxyResult.Error -> {
                    cont.resume(onProxyError(proxyResult.code, proxyResult.data, proxyResult.exception))
                }
            }
        }
    }

    protected fun onProxySuccess(code: Int, data: JSONObject): MessageResult<R> {
        return try {
            val resultData = request.parseResponse(data)
            MessageResult.Success(resultData)

        } catch (proxyException: ProxyException) {
            MessageResult.Error(code, "Failed to parse proxy response data!", proxyException)
        }
    }

    protected fun onProxyError(code: Int, data: JSONObject, exception: Exception): MessageResult<R> {
        // ToDo : добавить проверку вида ошибки авторизации - устарел ли токен или токен совсем невалидный.
        // От этого решать, пытаться ли обновлять токен или же сразу выбрасывать пользователя на реавторизацию

        return when (code) {
            HTTP_UNAUTHORIZED -> MessageResult.AuthError(data.toString(), exception)
            else -> MessageResult.Error(code, data.toString(), exception)
        }
    }

}