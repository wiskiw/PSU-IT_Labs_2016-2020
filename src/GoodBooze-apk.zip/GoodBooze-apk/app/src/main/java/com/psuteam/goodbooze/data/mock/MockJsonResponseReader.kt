package com.psuteam.goodbooze.data.mock

import com.psuteam.goodbooze.data.storage.reader.JsonAssetReader
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException

/**
 * Класс для чтения mock ответов сервера
 *
 * Created by Andrey Yablonsky on 21.05.2020.
 */
class MockJsonResponseReader(private val jsonAssetReader: JsonAssetReader) {

    @Throws(MockReadException::class)
    private fun readJsonMockFile(mockFilePath: String): JSONObject {
        try {
            return jsonAssetReader.readJsonAssetFile(mockFilePath)

        } catch (e: IOException) {
            throw MockReadException("Failed read JSON file '${mockFilePath}'!", e)

        } catch (e: JSONException) {
            throw MockReadException("Failed parse JSON file '${mockFilePath}'!", e)
        }
    }


    private fun buildMockFilPath(mockFolder: String, methodName: String, responseId: String?): String {
        if (responseId != null){
            return "${mockFolder}/${methodName}-${responseId}.json"
        } else {
            return "${mockFolder}/${methodName}.json"
        }
    }

    @Throws(MockReadException::class)
    fun read(mockFolder: String, methodName: String, responseId: String? = null): JSONObject {
        val mockFilePath = buildMockFilPath(mockFolder, methodName, responseId)
        return readJsonMockFile(mockFilePath)
    }

}