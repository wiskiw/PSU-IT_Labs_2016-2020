package com.psuteam.goodbooze.networking.endpoint.request

import com.psuteam.goodbooze.app.App
import com.psuteam.goodbooze.data.model.CreateProduct
import com.psuteam.goodbooze.data.model.Token
import com.psuteam.goodbooze.networking.endpoint.EndpointRequest
import com.psuteam.goodbooze.networking.proxy.Proxy
import com.psuteam.goodbooze.networking.proxy.ProxyException
import org.json.JSONException
import org.json.JSONObject

class CreateProductRequest(
    private val product: CreateProduct
) : EndpointRequest<String>() {

    override fun setup(app: App) {
        super.setup(app)

        val address = JSONObject().apply {
            put("name", product.address.name)
            put("latitude", product.address.latitude)
            put("longitude", product.address.longitude)
        }

        params.apply {
            put("title", product.title)
            put("imageId", product.imageId)
            put("userId", product.userId)
            put("price", product.price)
            put("address", address)
        }
    }

    override fun getMethodName(): String = "createProduct"

    override fun getMethod(): Proxy.Method = Proxy.Method.POST

    override fun parseResponse(data: JSONObject): String {
        try {
            return data.getString("id")
        } catch (e: JSONException) {
            throw ProxyException("Failed to parse JSON response.", e)
        }
    }

}