package com.psuteam.goodbooze.data.model

import java.io.Serializable

data class LoggedInUser(
    val id: String,
    val name: String,
    val login: String,
    var accessToken: Token,
    var refreshToken: Token,
    val userRole: UserRole
) : Serializable {

    enum class UserRole {
        REGULAR,
        MODERATOR,
    }

    fun getTokens(): TokenPair = TokenPair(accessToken, refreshToken)

}
