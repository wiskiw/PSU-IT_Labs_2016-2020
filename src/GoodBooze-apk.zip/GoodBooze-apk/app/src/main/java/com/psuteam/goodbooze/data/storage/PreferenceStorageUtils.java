package com.psuteam.goodbooze.data.storage;

import android.content.SharedPreferences;

import com.psuteam.goodbooze.data.storage.reader.PropertyReader;

import org.jetbrains.annotations.NotNull;

/**
 * Утилиты чтения/сохранения данных из {@link SharedPreferences} и {@link PropertyReader}
 *
 * ToDo: проверить на null safety
 *
 * Created by Andrey Yablonsky on 27.08.2019.
 */
public class PreferenceStorageUtils {

    /**
     * Читает {@link Boolean} значение по ключу #key из хранилища #sharedPreferences.
     * Если такого нет, то использует значение из #propertyReader.
     * Важно, #propertyReader обязательно должен содержать значение с ключом #key.
     *
     * @param sharedPreferences хранилище настроек
     * @param propertyReader хранилище стандартных настроек
     * @param key ключ для чтения значения
     */
    public static boolean readBool(SharedPreferences sharedPreferences, PropertyReader propertyReader, String key) {
        if (sharedPreferences.contains(key)) {
            try {
                return sharedPreferences.getBoolean(key, false);
            }
            catch (ClassCastException castException) {
                return propertyReader.getBool(key);
            }
        } else {
            return propertyReader.getBool(key);
        }
    }

    /**
     * Читает {@link Boolean} значение по ключу #key из хранилища #sharedPreferences.
     * Если такого нет, то вернет #defaultValue
     *
     * @param sharedPreferences хранилище настроек
     * @param key ключ для чтения значения
     * @param defaultValue возвращаемое значение, в случае ошибки чтения
     */
    public static Boolean readBool(SharedPreferences sharedPreferences, String key, Boolean defaultValue) {
        try {
            return sharedPreferences.getBoolean(key, defaultValue);
        }
        catch (ClassCastException castException) {
            return defaultValue;
        }
    }

    public static void saveBool(SharedPreferences sharedPreferences, String key, Boolean value) {
        sharedPreferences.edit()
            .putBoolean(key, value)
            .apply();
    }

    /**
     * Читает {@link String} значение по ключу #key из хранилища #sharedPreferences.
     * Если такого нет, то использует значение из #propertyReader.
     * Важно, #propertyReader обязательно должен содержать значение с ключом #key.
     *
     * @param sharedPreferences хранилище настроек
     * @param propertyReader хранилище стандартных настроек
     * @param key ключ для чтения значения
     */
    public static String readString(SharedPreferences sharedPreferences, PropertyReader propertyReader, String key) {
        if (sharedPreferences.contains(key)) {
            try {
                return sharedPreferences.getString(key, null);
            }
            catch (ClassCastException castException) {
                return propertyReader.getString(key);
            }
        } else {
            return propertyReader.getString(key);
        }
    }

    /**
     * Читает {@link String} значение по ключу #key из хранилища #sharedPreferences.
     *
     * @param sharedPreferences хранилище настроек
     * @param key ключ для чтения значения
     * @param defaultValue возвращаемое значение, в случае ошибки чтения
     */
    public static String readString(SharedPreferences sharedPreferences, String key, String defaultValue) {
        try {
            return sharedPreferences.getString(key, defaultValue);
        }
        catch (ClassCastException castException) {
            return defaultValue;
        }
    }

    /**
     * Записывает #value в хранилище #sharedPreferences с ключом #key.
     *
     * @param sharedPreferences хранилище настроек
     * @param key ключ для записи значения
     * @param value значение для записи
     */
    public static void saveString(SharedPreferences sharedPreferences, String key, String value) {
        sharedPreferences.edit()
            .putString(key, value)
            .apply();
    }

    /**
     * Читает {@link Integer} значение по ключу #key из хранилища #sharedPreferences.
     * Если такого нет, то использует значение из #propertyReader.
     * Важно, #propertyReader обязательно должен содержать значение с ключом #key.
     *
     * @param sharedPreferences хранилище настроек
     * @param propertyReader хранилище стандартных настроек
     * @param key ключ для чтения значения
     */
    public static Integer readInt(SharedPreferences sharedPreferences, PropertyReader propertyReader, String key) {
        if (sharedPreferences.contains(key)) {
            try {
                return sharedPreferences.getInt(key, 0);
            }
            catch (ClassCastException castException) {
                return propertyReader.getInt(key);
            }
        } else {
            return propertyReader.getInt(key);
        }
    }

    /**
     * Читает {@link Integer} значение по ключу #key из хранилища #sharedPreferences.
     *
     * @param sharedPreferences хранилище настроек
     * @param key ключ для чтения значения
     * @param defaultValue возвращаемое значение, в случае ошибки чтения
     */
    public static Integer readInt(SharedPreferences sharedPreferences, String key, Integer defaultValue) {
        if (sharedPreferences.contains(key)) {
            try {
                return sharedPreferences.getInt(key, 0);
            }
            catch (ClassCastException castException) {
                return defaultValue;
            }
        } else {
            return defaultValue;
        }
    }

    /**
     * Записывает #value в хранилище #sharedPreferences с ключом #key.
     *
     * @param sharedPreferences хранилище настроек
     * @param key ключ для записи значения
     * @param value значение для записи
     */
    public static void saveInt(SharedPreferences sharedPreferences, String key, Integer value) {
        sharedPreferences.edit()
            .putInt(key, value)
            .apply();
    }

    public static void saveDouble(SharedPreferences sharedPreferences, String key, Double value) {
        sharedPreferences.edit()
            .putString(key, String.valueOf(value))
            .apply();
    }

    @NotNull
    public static Double readDouble(SharedPreferences preferences, PropertyReader propertyReader, String key) {
        if (preferences.contains(key)) {
            try {
                String doubleValue = preferences.getString(key, propertyReader.getString(key));
                return Double.valueOf(doubleValue);
            }
            catch (ClassCastException castException) {
                return Double.valueOf(propertyReader.getString(key));
            }
        } else {
            return Double.valueOf(propertyReader.getString(key));
        }
    }

    public static Double readDouble(SharedPreferences preferences, String key, Double defaultValue) {
        if (preferences.contains(key)) {
            try {
                String doubleValue = preferences.getString(key, null);
                return doubleValue != null ? Double.valueOf(doubleValue) : defaultValue;
            }
            catch (ClassCastException | NumberFormatException castException) {
                return defaultValue;
            }
        } else {
            return defaultValue;
        }
    }

}
