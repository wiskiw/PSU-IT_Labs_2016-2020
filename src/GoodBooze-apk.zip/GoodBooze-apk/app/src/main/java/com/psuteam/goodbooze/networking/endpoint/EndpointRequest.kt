package com.psuteam.goodbooze.networking.endpoint

import com.psuteam.goodbooze.app.App
import com.psuteam.goodbooze.app.utils.Utils
import com.psuteam.goodbooze.networking.proxy.ProxyRequest
import com.psuteam.goodbooze.networking.proxy.UrlMethod
import org.json.JSONObject

abstract class EndpointRequest<out T : Any> : ProxyRequest<JSONObject, T>() {

    private lateinit var endpoint : String

    override fun setup(app: App) {
        super.setup(app)

        endpoint = app.preferences.readEndpoint()
    }

    abstract fun getMethodName() : String

    override fun getUrlMethod(): UrlMethod = UrlMethod(endpoint, getMethodName())
}