package com.psuteam.goodbooze.networking.proxy.volley

import com.android.volley.VolleyError

/**
 * A generic class that holds result value for [Proxy].
 *
 * R - type of result
 */
sealed class VolleyResult<in R : Any> {

    data class Success<R : Any>(val response: R) : VolleyResult<R>()
    data class Error<R : Any>(val volleyError: VolleyError) : VolleyResult<R>()

    override fun toString(): String {
        return when (this) {
            is Success<*> -> "Success[response=$response]"
            is Error -> "Error[exception=$volleyError]"
        }
    }
}
