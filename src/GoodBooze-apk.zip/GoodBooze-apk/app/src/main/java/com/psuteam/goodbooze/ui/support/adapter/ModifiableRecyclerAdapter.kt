package com.psuteam.goodbooze.ui.support.adapter

import androidx.recyclerview.widget.RecyclerView
import com.psuteam.goodbooze.ui.support.adapter.diffutil.DiffCallbackAdapter
import com.psuteam.goodbooze.ui.support.adapter.diffutil.RecyclerAdapterDiffUtil

/**
 * Адаптер на основе [ArrayList]. Позволяет обновлять список установленных элементов.
 */
abstract class ModifiableRecyclerAdapter<I, VH : RecyclerView.ViewHolder> : RecyclerView.Adapter<VH>(),
    DiffCallbackAdapter.ItemsDiffPredicate<I> {

    @Suppress("LeakingThis")
    private var diffCallbackAdapter: DiffCallbackAdapter<I> = DiffCallbackAdapter(this)
    private val items = ArrayList<I>()

    override fun getItemCount() = items.size

    fun getItems(): ArrayList<I> = items

    fun setItems(newItems: List<I>, detectMoves: Boolean = true) {
        RecyclerAdapterDiffUtil.updateDataList(this, diffCallbackAdapter, newItems, detectMoves)
    }

    fun get(position: Int): I = items[position]

    override fun areItemsSame(objectA: I, objectB: I): Boolean {
        return if (objectA != null) objectA == objectB else objectB == null
    }

    override fun areContentSame(objectA: I, objectB: I): Boolean {
        return if (objectA != null) objectA == objectB else objectB == null
    }
}