package com.psuteam.goodbooze.data.model

data class Comment(val id: String, val userId: String, val userName: String, val imageId: String, val text: String)