package com.psuteam.goodbooze.networking.endpoint.request

import com.psuteam.goodbooze.app.App
import com.psuteam.goodbooze.data.model.Token
import com.psuteam.goodbooze.data.model.TokenPair
import com.psuteam.goodbooze.networking.endpoint.EndpointRequest
import com.psuteam.goodbooze.networking.proxy.Proxy
import com.psuteam.goodbooze.networking.proxy.ProxyException
import org.json.JSONException
import org.json.JSONObject

/**
 * Refresh tokens request
 */
class RefreshTokenRequest(
    private val refreshToken: Token
) : EndpointRequest<TokenPair>() {

    companion object {
        private const val PARAM_KEY_REFRESH_TOKEN = "refreshToken"

        private const val RESPONSE_KEY_ACCESS_TOKEN = "accessToken"
        private const val RESPONSE_KEY_REFRESH_TOKEN = "refreshToken"

        private const val RESPONSE_KEY_TOKEN = "token"
        private const val RESPONSE_KEY_EXPIRATION = "expiration"
    }

    override fun setup(app: App) {
        super.setup(app)

        params.apply {
            put(PARAM_KEY_REFRESH_TOKEN, refreshToken.token)
        }
    }

    override fun getMethodName(): String = "updateToken"

    override fun getMethod(): Proxy.Method = Proxy.Method.GET

    override fun parseResponse(data: JSONObject): TokenPair {
        try {
            val accessToken = getToken(data, RESPONSE_KEY_ACCESS_TOKEN)
            val refreshToken = getToken(data, RESPONSE_KEY_REFRESH_TOKEN)
            return TokenPair(accessToken, refreshToken)

        } catch (e: JSONException) {
            throw ProxyException("Failed to parse JSON response.", e)
        }
    }

    @Throws(JSONException::class)
    private fun getToken(data: JSONObject, tokenKey: String): Token {
        val tokenJson = data.getJSONObject(tokenKey)
        return Token(tokenJson.getString(RESPONSE_KEY_TOKEN), tokenJson.getLong(RESPONSE_KEY_EXPIRATION))
    }
}