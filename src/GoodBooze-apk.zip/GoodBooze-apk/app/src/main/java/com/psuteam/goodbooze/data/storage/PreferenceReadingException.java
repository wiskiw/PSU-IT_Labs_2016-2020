package com.psuteam.goodbooze.data.storage;

/**
 * Ошибка при чтении отсутствующих данных
 *
 * Created by Andrey Yablonsky on 09.03.2019.
 */
public class PreferenceReadingException extends IllegalStateException {

    public PreferenceReadingException() {
    }

    public PreferenceReadingException(String s) {
        super(s);
    }

    public PreferenceReadingException(String message, Throwable cause) {
        super(message, cause);
    }

    public PreferenceReadingException(Throwable cause) {
        super(cause);
    }
}
