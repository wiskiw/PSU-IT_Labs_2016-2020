package com.psuteam.goodbooze.ui.details

import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import com.bumptech.glide.Glide
import com.psuteam.goodbooze.R
import com.psuteam.goodbooze.app.utils.UiUtils
import com.psuteam.goodbooze.data.model.Comment
import com.psuteam.goodbooze.ui.support.adapter.BindableViewHolder
import com.psuteam.goodbooze.ui.support.adapter.ModifiableRecyclerAdapter

/**
 * Comments list adapter
 */
class DetailsCommentsRecyclerAdapter :
    ModifiableRecyclerAdapter<Comment, DetailsCommentsRecyclerAdapter.DetailsCommentViewHolder>() {

    var clickListeners: ClickListeners? = null


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DetailsCommentViewHolder {
        return DetailsCommentViewHolder(parent, clickListeners)
    }

    override fun onBindViewHolder(holder: DetailsCommentViewHolder, position: Int) {
        holder.bind(get(position))
    }

    interface ClickListeners {

        fun onClick(comment: Comment)

    }

    class DetailsCommentViewHolder(root: ViewGroup, private val clickListeners: ClickListeners?) :
        BindableViewHolder(UiUtils.inflate(root, R.layout.comment_item)) {

        private val nameView: TextView
        private val userImage: ImageView
        private val commentTextView: TextView

        init {
            with(itemView) {
                nameView = findViewById(R.id.nameView)
                userImage = findViewById(R.id.userImage)
                commentTextView = findViewById(R.id.commentTextView)
            }
        }

        @Suppress("PARAMETER_NAME_CHANGED_ON_OVERRIDE")
        override fun <I> bind(comment: I) {
            if (comment !is Comment) {
                return
            }

            itemView.setOnClickListener { clickListeners?.onClick(comment) }

            Glide.with(itemView.context)
                .load(comment.imageId)
                .centerCrop()
                .placeholder(R.drawable.ic_placeholder)
                .into(userImage)

            nameView.text = comment.userName
            commentTextView.text = comment.text
        }

    }

}