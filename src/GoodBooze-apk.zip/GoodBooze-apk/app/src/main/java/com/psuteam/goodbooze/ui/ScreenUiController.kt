package com.psuteam.goodbooze.ui

import android.view.View
import android.widget.TextView
import androidx.appcompat.app.ActionBar
import androidx.drawerlayout.widget.DrawerLayout
import com.psuteam.goodbooze.R
import com.psuteam.goodbooze.app.utils.UiUtils

class ScreenUiController(
    private val supportActionBar: ActionBar,
    private val drawerLayout: DrawerLayout,
    drawerHeader: View
) {

    enum class ScreenStyle {
        DEFAULT,
        NOT_AUTHED_FULL_SCREEN,
        NOT_AUTHED_TOOLBAR,
        NOT_AUTHED_TOOLBAR_CHILD,
        AUTHED_TOOLBAR,
        AUTHED_TOOLBAR_CHILD
    }

    enum class NavigationIcon {
        INVISIBLE,
        SANDWICH,
        ARROW
    }

    private val nameView = drawerHeader.findViewById<TextView>(R.id.navHeaderName)
    private val loginView = drawerHeader.findViewById<TextView>(R.id.navHeaderLogin)

    fun setTitle(title: String) {
        supportActionBar.title = title
    }

    fun disableDrawer() {
        drawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED)
    }

    fun enableDrawer() {
        drawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED)
    }

    fun hideToolbar() {
        supportActionBar.hide()
    }

    fun showToolbar() {
        supportActionBar.show()
    }

    fun changeNavigationIcon(navigationIcon: NavigationIcon) {
        when (navigationIcon) {
            NavigationIcon.INVISIBLE -> {
                supportActionBar.setDisplayHomeAsUpEnabled(false)
            }
            NavigationIcon.SANDWICH -> {
                supportActionBar.setDisplayHomeAsUpEnabled(true)
                supportActionBar.setHomeButtonEnabled(true)
            }
            NavigationIcon.ARROW -> {
                supportActionBar.setDisplayHomeAsUpEnabled(true)
                supportActionBar.setDisplayShowHomeEnabled(true)
            }
        }
    }

    fun changeScreenStyle(screenStyle: ScreenStyle) {
        when (screenStyle) {
            ScreenStyle.DEFAULT -> {
                showToolbar()
                disableDrawer()
                changeNavigationIcon(NavigationIcon.INVISIBLE)
            }
            ScreenStyle.NOT_AUTHED_FULL_SCREEN -> {
                hideToolbar()
                disableDrawer()
            }
            ScreenStyle.NOT_AUTHED_TOOLBAR -> {
                showToolbar()
                disableDrawer()
                changeNavigationIcon(NavigationIcon.INVISIBLE)
            }
            ScreenStyle.NOT_AUTHED_TOOLBAR_CHILD -> {
                showToolbar()
                disableDrawer()
                changeNavigationIcon(NavigationIcon.ARROW)
            }

            ScreenStyle.AUTHED_TOOLBAR -> {
                showToolbar()
                enableDrawer()
                changeNavigationIcon(NavigationIcon.SANDWICH)
            }
            ScreenStyle.AUTHED_TOOLBAR_CHILD -> {
                showToolbar()
                disableDrawer()
                changeNavigationIcon(NavigationIcon.ARROW)
            }
        }
    }

    fun setDrawerUser(name: String? = null, login: String? = null) {
        UiUtils.setVisibility(name != null, nameView)
        name?.let { nameView.text = name }

        UiUtils.setVisibility(login != null, loginView)
        login?.let { loginView.text = login }
    }


}