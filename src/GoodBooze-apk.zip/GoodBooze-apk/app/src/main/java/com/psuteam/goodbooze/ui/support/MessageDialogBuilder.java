package com.psuteam.goodbooze.ui.support;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;

import androidx.appcompat.app.AlertDialog;

import com.psuteam.goodbooze.R;

/**
 * Класс для создания диалога-списка одиночного выбора.
 */
public class MessageDialogBuilder {

    private Context context;

    private Integer icon;
    private String title;
    private String message;

    private String primaryActionLabel;
    private DialogInterface.OnClickListener primaryAction;

    private String secondaryActionLabel;
    private DialogInterface.OnClickListener secondaryAction;

    public MessageDialogBuilder(Context context) {
        this.context = context;
    }

    public void setIcon(Integer icon) {
        this.icon = icon;
    }

    /**
     * Устанавливает заголовок диалога.
     * Если передан {@code null} заголовок не будет отображен.
     */
    public MessageDialogBuilder setTitle(String title) {
        this.title = title;
        return this;
    }

    /**
     * Устанавливает сообщение диалога.
     */
    public MessageDialogBuilder setMessage(String message) {
        this.message = message;
        return this;
    }

    /**
     * Устанавливает текст и действие клика по основной кнопке.
     * По дефолту или при {@code null} значение отображается кнопка ок, при клики закрывается диалог
     */
    public MessageDialogBuilder setPrimaryAction(String label, DialogInterface.OnClickListener action) {
        this.primaryActionLabel = label;
        this.primaryAction = action;
        return this;
    }

    public MessageDialogBuilder setPrimaryAction(DialogInterface.OnClickListener action) {
        setPrimaryAction(null, action);
        return this;
    }

    /**
     * Устанавливает действие клика по второстепенной кнопке.
     */
    public MessageDialogBuilder setSecondaryAction(String label, DialogInterface.OnClickListener action) {
        this.secondaryActionLabel = label;
        this.secondaryAction = action;
        return this;
    }

    public MessageDialogBuilder setSecondaryAction(DialogInterface.OnClickListener action) {
        setSecondaryAction(null, action);
        return this;
    }

    /**
     * Создает диалог
     */
    public Dialog build() {

        AlertDialog.Builder builder = new AlertDialog.Builder(context)
                .setTitle(title)
                .setMessage(message);

        if (icon != null) {
            builder.setIcon(icon);
        }

        // The dialog is automatically dismissed when a dialog button is clicked.
        // A null listener allows the button to dismiss the dialog and take no further primaryAction.
        if (primaryActionLabel != null) {
            builder.setPositiveButton(primaryActionLabel, primaryAction);
        } else {
            builder.setPositiveButton(R.string.ok_label, primaryAction);
        }

        if (secondaryAction != null) {
            // The dialog is automatically dismissed when a dialog button is clicked.
            if (secondaryActionLabel != null) {
                builder.setNegativeButton(secondaryActionLabel, secondaryAction);
            } else {
                builder.setNegativeButton(R.string.cancel_label, secondaryAction);
            }
        }

        return builder.create();
    }

}
