package com.psuteam.goodbooze.ui

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.psuteam.goodbooze.app.logger.LoggerFactory
import com.psuteam.goodbooze.data.model.LoggedInUser

/**
 * Базовый фрагмент для авторизованной части приложения
 */
open class LoggedInFragment : RootNavigationFragment() {

    companion object {
        private val LOGGER = LoggerFactory.getLogger(LoggedInFragment::class.java)
    }

    protected lateinit var fragmentContainer: LoggedInFragmentContainer

    protected lateinit var screenUiController: ScreenUiController
        private set

    protected lateinit var loggedInUser: LoggedInUser
        private set

    override fun onAttach(context: Context) {
        super.onAttach(context)

        if (context is LoggedInFragmentContainer) {
            fragmentContainer = context

        } else {
            throw IllegalArgumentException(
                "${this.javaClass.canonicalName} container must implement ${LoggedInFragmentContainer::class.java.canonicalName}!"
            )
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        loggedInUser = fragmentContainer.getLoggedInUser()
        screenUiController = fragmentContainer.getScreenUiController()
    }
}
