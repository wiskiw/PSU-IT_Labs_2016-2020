package com.psuteam.goodbooze.ui.feed

import android.view.ViewGroup
import com.psuteam.goodbooze.R
import com.psuteam.goodbooze.app.utils.UiUtils
import com.psuteam.goodbooze.data.model.Product
import com.psuteam.goodbooze.ui.support.adapter.BindableViewHolder
import com.psuteam.goodbooze.ui.support.adapter.pagination.LoadableAdapter

/**
 * Recommendation list adapter
 */
class FeedRecyclerAdapter : LoadableAdapter<Product, FeedViewHolder>() {

    var clickListeners : ClickListeners? = null

    fun setProducts(operations: List<Product>) {
        setContentItems(operations)
    }

    override fun onCreateContentItemViewHolder(root: ViewGroup, viewType: Int): FeedViewHolder {
        return FeedViewHolder(root, clickListeners)
    }

    override fun onCreateLoadingViewHolder(root: ViewGroup): BindableViewHolder {
        return FeedLoadingViewHolder(root)
    }

    class FeedLoadingViewHolder(root: ViewGroup) : BindableViewHolder(UiUtils.inflate(root, R.layout.feed_loading_item))

    interface ClickListeners {

        fun onClick(product: Product)

    }

}