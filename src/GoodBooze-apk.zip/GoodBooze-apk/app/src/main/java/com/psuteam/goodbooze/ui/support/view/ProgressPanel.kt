package com.psuteam.goodbooze.ui.support.view

import android.content.Context
import android.util.AttributeSet
import android.view.View
import android.widget.FrameLayout
import com.psuteam.goodbooze.R
import com.psuteam.goodbooze.app.utils.UiUtils
import com.psuteam.goodbooze.networking.ProgressIndicator

/**
 * Компонент, отображающий индикатор загрузки.
 * По умолчанию - индикатор скрыт.
 *
 * @author Andrey Yablonsky
 */
class ProgressPanel : FrameLayout, ProgressIndicator {

    constructor(context: Context) : super(context)
    constructor(context: Context, attrs: AttributeSet?) : super(context, attrs)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(context, attrs, defStyleAttr)

    private var progressView: View = UiUtils.inflate(context, R.layout.progress_panel_view)
    private var refreshRequestCount = 0

    init {
        // пустой обработчик для перехвата кликов
        progressView.setOnClickListener {}
        UiUtils.setVisibility(false, progressView)
    }

    override fun showProgress() {
        if (indexOfChild(progressView) < 0) {
            addView(progressView)
        }
        changeProgressVisibility(true)
    }

    override fun hideProgress() {
        changeProgressVisibility(false)
    }

    private fun changeProgressVisibility(show: Boolean) {
        // todo
//        Utils.checkFalse(refreshRequestCount < 0, "refreshRequestCount should never be less than 0!" +
//                " Did you call hideProgress() before show?")
//
//        refreshRequestCount += if (show) 1 else -1
//        val progressShow = refreshRequestCount > 0
//        UiUtils.setVisibility(progressShow, progressView)
        UiUtils.setVisibility(show, progressView)
    }

    override fun isProgressVisible(): Boolean = progressView.visibility == View.VISIBLE

}
