package com.psuteam.goodbooze.ui.moderatorfeed

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.psuteam.goodbooze.R
import com.psuteam.goodbooze.app.logger.LoggerFactory
import com.psuteam.goodbooze.data.model.Product
import com.psuteam.goodbooze.networking.endpoint.request.ModerProductsRequest
import com.psuteam.goodbooze.networking.messenger.AuthedMessenger
import com.psuteam.goodbooze.networking.messenger.MessageResult
import com.psuteam.goodbooze.ui.LoggedInFragment
import com.psuteam.goodbooze.ui.ScreenUiController
import com.psuteam.goodbooze.ui.feed.FeedFragment
import com.psuteam.goodbooze.ui.feed.ModerFeedRecyclerAdapter
import com.psuteam.goodbooze.ui.support.MessageDialogBuilder
import com.psuteam.goodbooze.ui.support.adapter.pagination.PaginationListener
import kotlinx.android.synthetic.main.fragment_feed.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

/**
 * A [Fragment] for Drinks feed screen.
 */
class ModeratorFeedFragment : LoggedInFragment() {

    companion object {
        private val LOGGER = LoggerFactory.getLogger(FeedFragment::class.java)
        private const val PAGE_SIZE = 4
        private const val PAGE_COUNT = 1
    }

    private lateinit var productAdapter: ModerFeedRecyclerAdapter

    private var isLoading: Boolean = false
    private var isLastPage: Boolean = false

    private val products = mutableListOf<Product>()
    private var page: Int = 0

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_moder_feed, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        screenUiController.setTitle(getString(R.string.moder_feed_title))
        screenUiController.changeScreenStyle(ScreenUiController.ScreenStyle.AUTHED_TOOLBAR_CHILD)

        val linearLayoutManager = LinearLayoutManager(context)

        productAdapter = ModerFeedRecyclerAdapter()
        productAdapter.clickListeners = ProductClickListener()
        feedRecycler.layoutManager = linearLayoutManager
        feedRecycler.adapter = productAdapter
        feedRecycler.addOnScrollListener(ProductPaginationListener(linearLayoutManager))


        if (products.isEmpty()) {
            loadMore(0, PAGE_SIZE)
        } else {
            productAdapter.setProducts(products)
            productAdapter.applyAdapterContentChanges()
        }
    }

    private fun loadMore(offset: Int, count: Int) {
        GlobalScope.launch(Dispatchers.Main) {

            changeLoadingState(true)
            productAdapter.applyAdapterContentChanges()

            loadProducts(offset, count)
            changeLoadingState(false)

            productAdapter.applyAdapterContentChanges()
        }
    }

    private fun changeLoadingState(isLoading: Boolean) {
        this.isLoading = isLoading
        productAdapter.isLoading = isLoading
    }

    private suspend fun loadProducts(offset: Int, count: Int) {
        val request = ModerProductsRequest(offset, count)

        if (page < PAGE_COUNT) {
            isLastPage = false
            val mockFileId = page.toString()
            page++

            val result = AuthedMessenger(app, app.getJsonProxy(mockFileId), request)
                .apply { navController = super.navController }
                .send()

            if (result is MessageResult.Success) {
                products.addAll(result.data)
                productAdapter.setProducts(products)
            }

        } else {
            isLastPage = true
        }

    }

    private fun showProductApproveDialog(product: Product) {
        MessageDialogBuilder(context)
            .setTitle(getString(R.string.moder_feed_approve_dialog_title))
            .setMessage(getString(R.string.moder_feed_approve_dialog_text, product.title))
            .setPrimaryAction(getString(R.string.moder_feed_approve_dialog_button_approve)) { dialog, which ->
                approveProduct(product)
                dialog.cancel()
            }
            .setSecondaryAction(getString(R.string.moder_feed_approve_dialog_button_deny)) { dialog, which ->
                denyProduct(product)
                dialog.cancel()
            }
            .build()
            .show()
    }

    private fun approveProduct(product: Product) {
        products.remove(product)
        productAdapter.setProducts(products)
        productAdapter.applyAdapterContentChanges()
    }

    private fun denyProduct(product: Product) {
        products.remove(product)
        productAdapter.setProducts(products)
        productAdapter.applyAdapterContentChanges()
    }

    inner class ProductClickListener : ModerFeedRecyclerAdapter.ClickListeners {

        override fun onClick(product: Product) {
            val action = ModeratorFeedFragmentDirections.actionModeratorFeedFragmentToDetailsFragment(product.id)
            navController.navigate(action)
        }

        override fun onLongClick(product: Product): Boolean {
            return if (!isLoading){
                showProductApproveDialog(product)
                true
            } else {
                false
            }
        }
    }

    inner class ProductPaginationListener(layoutManager: LinearLayoutManager) : PaginationListener(layoutManager, PAGE_SIZE) {

        override val isLastPage: Boolean
            get() = this@ModeratorFeedFragment.isLastPage

        override val isLoading: Boolean
            get() = this@ModeratorFeedFragment.isLoading

        override fun loadMoreItems(offset: Int, count: Int) {
            loadMore(offset, count)
        }
    }

}