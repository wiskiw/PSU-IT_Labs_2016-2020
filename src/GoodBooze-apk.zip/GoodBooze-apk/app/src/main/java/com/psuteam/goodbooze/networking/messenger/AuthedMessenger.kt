package com.psuteam.goodbooze.networking.messenger

import androidx.navigation.NavController
import com.psuteam.goodbooze.app.App
import com.psuteam.goodbooze.app.logger.LoggerFactory
import com.psuteam.goodbooze.data.model.Token
import com.psuteam.goodbooze.data.model.TokenPair
import com.psuteam.goodbooze.networking.ErrorIndicator
import com.psuteam.goodbooze.networking.ProgressIndicator
import com.psuteam.goodbooze.networking.endpoint.request.RefreshTokenRequest
import com.psuteam.goodbooze.networking.proxy.Proxy
import com.psuteam.goodbooze.networking.proxy.ProxyRequest
import com.psuteam.goodbooze.ui.NavUtils
import org.json.JSONObject

/**
 * Messenger implementation with check if server access token is valid and refresh it if required.
 * After that send [authedRequest] using [proxy].
 *
 * Helps to do authed request to the server.
 */
class AuthedMessenger<out D : Any>(
    private val app: App,
    private val proxy: Proxy<JSONObject>,
    private val authedRequest: ProxyRequest<JSONObject, D>
) : Messenger<D> {

    companion object{
        private val LOGGER = LoggerFactory.getLogger(AuthedMessenger::class.java)
        private const val MAX_UPDATE_TOKENS_CALLS = 3
    }

    private var updateTokensCallCounter = 0

    var navController: NavController? = null
    var progressIndicator: ProgressIndicator? = null
    var errorIndicator: ErrorIndicator? = null

    @Suppress("MoveVariableDeclarationIntoWhen", "LiftReturnOrAssignment")
    override suspend fun send(): MessageResult<D> {
        progressIndicator?.showProgress()
        errorIndicator?.hide()

        val tokens = app.dataStorageProvider.userStorage.readTokens()

        if (tokens != null) {
            if (tokens.accessToken.isValid()) {
                return sendAuthedRequest(tokens)
            } else {
                LOGGER.debug("Access token is not valid. Trying to refresh tokens...")
                return tryUpdateRefreshToken(tokens.refreshToken)
            }
        } else {
            return tokensAuthFailed()
        }
    }

    private suspend fun tryUpdateRefreshToken(refreshToken: Token): MessageResult<D> {
        if (refreshToken.isValid()) {
            return updateAccessToken(refreshToken)
        } else {
            LOGGER.debug("Refresh token is not valid.")
            return tokensAuthFailed()
        }
    }

    private fun tokensAuthFailed(e : Exception? = null): MessageResult<D> {
        progressIndicator?.hideProgress()

        LOGGER.warn("Token auth failed! Relogin required!", e)

        navController?.let {
            LOGGER.debug("Navigating to login screen...")

            navController?.let { NavUtils.goToAuthActivity(it) }
        }

        return MessageResult.AuthError(
            message = "No valid user credits found.",
            exception = IllegalStateException("No valid user credits found", e)
        )
    }

    @Suppress("MoveVariableDeclarationIntoWhen")
    private suspend fun updateAccessToken(refreshToken: Token): MessageResult<D> {
        updateTokensCallCounter++
        if (updateTokensCallCounter > MAX_UPDATE_TOKENS_CALLS) {
            val attemptException = IllegalStateException("Too many tokens update attempts ($updateTokensCallCounter)!")
            LOGGER.warn("Updating tokens failed! Too many tokens update attempts ($updateTokensCallCounter).")
            return tokensAuthFailed(attemptException)

        } else {
            LOGGER.debug("Updating tokens [attempt: ${updateTokensCallCounter}]...")

            val refreshTokenRequest = RefreshTokenRequest(refreshToken)
            val updateTokenResult = JsonMessenger(app, proxy, refreshTokenRequest).send()

            return when (updateTokenResult) {
                is MessageResult.Success -> onTokenUpdated(updateTokenResult.data)
                is MessageResult.AuthError -> {
                    progressIndicator?.hideProgress()
                    errorIndicator?.showError(updateTokenResult.message)
                    tokensAuthFailed(updateTokenResult.exception)
                }
                is MessageResult.Error -> {
                    progressIndicator?.hideProgress()
                    errorIndicator?.showError(updateTokenResult.message)
                    MessageResult.Error(updateTokenResult.code, updateTokenResult.message, updateTokenResult.exception)
                }
            }
        }
    }

    private suspend fun onTokenUpdated(tokenPair: TokenPair): MessageResult<D> {
        LOGGER.debug("The tokens have been updated!")
        app.dataStorageProvider.userStorage.updateTokens(tokenPair)
        return sendAuthedRequest(tokenPair)
    }

    /**
     * Send [authedRequest] request with valid tokens
     */
    @Suppress("MoveVariableDeclarationIntoWhen")
    private suspend fun sendAuthedRequest(tokens: TokenPair): MessageResult<D> {
        authedRequest.setup(app)

        // ToDo: fix it to server implementation
        authedRequest.authorization = tokens.accessToken.token

        val authedRequestResult = JsonMessenger(app, proxy, authedRequest).send()

        progressIndicator?.hideProgress()
        return when (authedRequestResult) {
            is MessageResult.Success -> authedRequestResult
            is MessageResult.AuthError -> tryUpdateRefreshToken(tokens.refreshToken)
            is MessageResult.Error -> {
                errorIndicator?.showError(authedRequestResult.message)
                authedRequestResult
            }
        }
    }

}
