package com.psuteam.goodbooze.ui.support.adapter.pagination

import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

/**
 * Supporting only LinearLayoutManager
 *
 * Src: https://androidwave.com/pagination-in-recyclerview/
 */
abstract class PaginationListener(
    private val layoutManager: LinearLayoutManager,
    private val pageSize: Int
) : RecyclerView.OnScrollListener() {

    abstract val isLastPage: Boolean
    abstract val isLoading: Boolean

    override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
        super.onScrolled(recyclerView, dx, dy)
        val firstVisibleItemPosition = layoutManager.findFirstVisibleItemPosition()
        val visibleItemCount = layoutManager.childCount
        val totalItemCount = layoutManager.itemCount

        if (!isLoading && !isLastPage) {
            if (
                firstVisibleItemPosition + visibleItemCount >= totalItemCount
                && firstVisibleItemPosition >= 0
                && totalItemCount >= pageSize
            ) {
                loadMoreItems(totalItemCount, pageSize)
            }
        }
    }

    protected abstract fun loadMoreItems(offset: Int, count: Int)


}