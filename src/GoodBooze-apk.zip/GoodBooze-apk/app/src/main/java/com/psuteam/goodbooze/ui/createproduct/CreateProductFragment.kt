package com.psuteam.goodbooze.ui.createproduct

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import com.psuteam.goodbooze.R
import com.psuteam.goodbooze.app.logger.LoggerFactory
import com.psuteam.goodbooze.data.model.Address
import com.psuteam.goodbooze.data.model.CreateProduct
import com.psuteam.goodbooze.networking.ErrorIndicator
import com.psuteam.goodbooze.networking.endpoint.request.CreateProductRequest
import com.psuteam.goodbooze.networking.messenger.AuthedMessenger
import com.psuteam.goodbooze.networking.messenger.MessageResult
import com.psuteam.goodbooze.ui.LoggedInFragment
import com.psuteam.goodbooze.ui.ScreenUiController
import kotlinx.android.synthetic.main.fragment_create_product.*
import kotlinx.android.synthetic.main.fragment_create_product.view.*
import kotlinx.android.synthetic.main.fragment_details.errorPanel
import kotlinx.android.synthetic.main.fragment_details.progressPanel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

class CreateProductFragment : LoggedInFragment() {

    companion object {
        private val LOGGER = LoggerFactory.getLogger(CreateProductFragment::class.java)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_create_product, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        screenUiController.setTitle(getString(R.string.create_product_title))
        screenUiController.changeScreenStyle(ScreenUiController.ScreenStyle.AUTHED_TOOLBAR_CHILD)

        errorPanel.setRetryListener(RetryListener())

        createButton.setOnClickListener { save() }
    }

    private fun createProduct(createProduct: CreateProduct) {
        GlobalScope.launch(Dispatchers.Main) {

            val result = AuthedMessenger(app, app.getJsonProxy(), CreateProductRequest(createProduct))
                .apply {
                    navController = super.navController
                    errorIndicator = errorPanel
                    progressIndicator = progressPanel
                }
                .send()

            if (result is MessageResult.Success) {
                onProductCreated(result.data)
            }
        }
    }

    private fun save() {

        val address = Address(addressEdit.text.toString(), .0, .0)

        val product = CreateProduct(
            title = titleEdit.text.toString(),
            price = priceEdit.priceEdit.toString().toDoubleOrNull() ?: 0.0,
            description = descriptionEdit.text.toString(),
            address = address,
            userId = loggedInUser.id,
            imageId = imageEdit.text.toString()
        )

        createProduct(product)
    }

    private fun onProductCreated(productId: String) {
        Toast.makeText(requireContext(), getString(R.string.create_product_created_success, productId), Toast.LENGTH_LONG).show()
        navController.popBackStack()
    }

    inner class RetryListener : ErrorIndicator.RetryListener {
        override fun onRetry() {
            save()
        }
    }
}