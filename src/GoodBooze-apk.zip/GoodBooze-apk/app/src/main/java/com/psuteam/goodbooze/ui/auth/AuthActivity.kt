package com.psuteam.goodbooze.ui.auth

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.NavController
import androidx.navigation.NavDestination
import androidx.navigation.Navigation
import com.psuteam.goodbooze.R
import com.psuteam.goodbooze.app.App
import com.psuteam.goodbooze.app.utils.UiUtils
import com.psuteam.goodbooze.ui.LoggedInActivity

/**
 * Activity-контейнер для неавторизованной части приложения
 */
class AuthActivity : AppCompatActivity() {

    private lateinit var app: App
    private lateinit var navController: NavController

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_auth)

        app = application as App

        navController = Navigation.findNavController(this, R.id.navHostFragment)
    }

    override fun onBackPressed() {
        if (!navController.popBackStack()) {
            // ToDo handle back click if launched from AuthMessenger
            super.onBackPressed()
        }
    }
}
