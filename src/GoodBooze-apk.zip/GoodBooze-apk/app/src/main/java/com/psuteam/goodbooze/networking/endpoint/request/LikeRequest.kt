package com.psuteam.goodbooze.networking.endpoint.request

import com.psuteam.goodbooze.app.App
import com.psuteam.goodbooze.data.model.LoggedInUser
import com.psuteam.goodbooze.data.model.Token
import com.psuteam.goodbooze.networking.endpoint.EndpointRequest
import com.psuteam.goodbooze.networking.proxy.Proxy
import com.psuteam.goodbooze.networking.proxy.ProxyException
import org.json.JSONException
import org.json.JSONObject

class LikeRequest(
    private val productId: String,
    private val isLike: Boolean
) : EndpointRequest<Boolean>() {


    override fun setup(app: App) {
        super.setup(app)

        params.apply {
            put("productId", productId)
            put("isLike", isLike)
        }
    }

    override fun getMethodName(): String = "like"

    override fun getMethod(): Proxy.Method = Proxy.Method.GET

    override fun parseResponse(data: JSONObject): Boolean = true

}