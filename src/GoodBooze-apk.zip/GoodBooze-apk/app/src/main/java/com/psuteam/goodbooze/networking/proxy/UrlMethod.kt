package com.psuteam.goodbooze.networking.proxy

import com.psuteam.goodbooze.app.utils.Utils

class UrlMethod(val endpoint: String, val methodName: String) {

    fun getUrl(): String = Utils.buildUrl(endpoint, methodName)

    override fun toString(): String = "UrlMethod[endpoint=${endpoint}, methodName=${methodName}]"
}