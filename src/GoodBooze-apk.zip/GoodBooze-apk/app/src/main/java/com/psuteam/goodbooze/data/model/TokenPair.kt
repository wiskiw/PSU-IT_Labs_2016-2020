package com.psuteam.goodbooze.data.model

import java.io.Serializable

/**
 * Pair of access and refresh tokens
 */
data class TokenPair(val accessToken: Token, val refreshToken: Token) : Serializable {

    fun isValid() = accessToken.isValid() && refreshToken.isValid()

}