package com.psuteam.goodbooze.ui.feed

import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import com.bumptech.glide.Glide
import com.psuteam.goodbooze.R
import com.psuteam.goodbooze.app.utils.UiUtils
import com.psuteam.goodbooze.data.model.Product
import com.psuteam.goodbooze.ui.support.adapter.BindableViewHolder

/**
 * ViewHolder for displaying [Product] in the list
 *
 * @author Andrey Yablonsky
 */
class FeedViewHolder(root: ViewGroup, private val clickListeners: FeedRecyclerAdapter.ClickListeners?) :
    BindableViewHolder(UiUtils.inflate(root, R.layout.feed_item)) {

    private val name: TextView
    private val location: TextView
    private val price: TextView
    private val likesCounter: TextView
    private val image: ImageView

    init {
        with(itemView) {
            name = findViewById(R.id.name)
            location = findViewById(R.id.locationText)
            price = findViewById(R.id.priceText)
            likesCounter = findViewById(R.id.likesCounterText)
            image = findViewById(R.id.image)
        }
    }

    @Suppress("PARAMETER_NAME_CHANGED_ON_OVERRIDE")
    override fun <I> bind(product: I) {
        if (product !is Product){
            return
        }

        itemView.setOnClickListener { clickListeners?.onClick(product) }

        Glide.with(itemView.context)
            .load(product.imageId)
            .centerCrop()
            .placeholder(R.drawable.ic_placeholder)
            .into(image)

        name.text = product.title
        location.text = product.address.name
        likesCounter.text = product.likes.toString()
        price.text = product.price.toString()
    }

}