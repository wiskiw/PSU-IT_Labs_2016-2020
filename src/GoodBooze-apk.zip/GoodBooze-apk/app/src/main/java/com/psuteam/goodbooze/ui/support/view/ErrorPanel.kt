package com.psuteam.goodbooze.ui.support.view

import android.content.Context
import android.util.AttributeSet
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.TextView
import com.psuteam.goodbooze.R
import com.psuteam.goodbooze.app.logger.LoggerFactory
import com.psuteam.goodbooze.app.utils.UiUtils
import com.psuteam.goodbooze.networking.ErrorIndicator

/**
 * По умолчанию - индикатор скрыт.
 * @author Andrey Yablonsky
 */
class ErrorPanel : FrameLayout, ErrorIndicator {

    companion object {
        private val LOGGER = LoggerFactory.getLogger(ErrorPanel::class.java)
    }

    constructor(context: Context) : super(context)
    constructor(context: Context, attrs: AttributeSet?) : super(context, attrs)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(context, attrs, defStyleAttr)

    private val view: View = UiUtils.inflate(context, R.layout.error_panel_view)
    private val errorTextView: TextView = view.findViewById(R.id.errorTextView)
    private val retryButton: Button = view.findViewById(R.id.retryButton)

    init {
        changeVisibility(false)
    }

    private fun changeVisibility(show: Boolean) {
        UiUtils.setVisibility(show, view)
    }

    override fun showError(message: String, isRetryAllow: Boolean) {
        if (indexOfChild(view) < 0) {
            addView(view)
        }
        changeVisibility(true)

        errorTextView.text = message
        UiUtils.setVisibility(isRetryAllow, retryButton)
    }

    override fun hide() {
        changeVisibility(false)
    }

    override val isVisible: Boolean = view.visibility == View.VISIBLE

    override fun setRetryListener(listener: ErrorIndicator.RetryListener?) {
        listener
            ?.let { retryButton.setOnClickListener { listener.onRetry() } }
            ?: retryButton.setOnClickListener { hide() }
    }
}
