package com.psuteam.goodbooze.networking.proxy

import com.psuteam.goodbooze.app.App
import org.json.JSONObject

/**
 * A message to server. Contains information to connect to a [Proxy] server (url, headers, params, etc.).
 * And how to handle a response from [Proxy].
 */
abstract class ProxyRequest<in D : Any, out R : Any> {

    private var isSetupCalled = false
    protected lateinit var app: App

    // ToDo: fix it to server implementation
    var authorization : String? = null

    open val headers: Map<String, String> = mapOf()
        get() {
            checkIfSetupCalled()
            return field
        }

    open val params: JSONObject = JSONObject()
        get() {
            checkIfSetupCalled()
            return field
        }


    open fun setup(app: App) {
        this.app = app
        isSetupCalled = true
    }

    private fun checkIfSetupCalled() {
        if (!isSetupCalled) {
            throw IllegalStateException("You must setup ProxyRequest before use it!")
        }
    }

    abstract fun getUrlMethod(): UrlMethod

    abstract fun getMethod(): Proxy.Method

    @Throws(ProxyException::class)
    abstract fun parseResponse(data: D): R

}