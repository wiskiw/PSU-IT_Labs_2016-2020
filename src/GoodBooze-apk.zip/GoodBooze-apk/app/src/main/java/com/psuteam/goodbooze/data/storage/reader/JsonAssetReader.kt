package com.psuteam.goodbooze.data.storage.reader

import android.content.Context
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import java.io.InputStream

/**
 * Класс для чтения JSON assets файлов
 *
 * Created by Andrey Yablonsky on 21.05.2019.
 */
class JsonAssetReader(private val context: Context) {

    @Throws(IOException::class, JSONException::class)
    fun readJsonAssetFile(mockFilePath: String): JSONObject {
        return JSONObject(readAssetFile(mockFilePath))
    }

    @Throws(IOException::class)
    private fun readAssetFile(filePath: String): String {
        val inputStream: InputStream = context.assets.open(filePath)
        val size = inputStream.available()
        val buffer = ByteArray(size)
        inputStream.read(buffer)
        inputStream.close()

        return buffer.toString(Charsets.UTF_8)
    }

}