package com.psuteam.goodbooze.data.storage

import android.content.SharedPreferences
import com.psuteam.goodbooze.app.logger.LoggerFactory
import com.psuteam.goodbooze.app.utils.ObjectSerializer
import com.psuteam.goodbooze.data.model.LoggedInUser
import com.psuteam.goodbooze.data.model.TokenPair

class UserStorage(private val sharedPreferences: SharedPreferences) {

    companion object {
        private val LOGGER = LoggerFactory.getLogger(UserStorage::class.java)

        private const val PREF_KEY_LOGGED_IN_USER = "loggedInUser"
    }

    fun readTokens(): TokenPair? {
        return readLoggedInUser()?.getTokens()
    }

    fun updateTokens(tokens: TokenPair) {
        val user = readLoggedInUser()
        if (user != null) {
            user.accessToken = tokens.accessToken
            user.refreshToken = tokens.refreshToken

        } else {
            LOGGER.error("Unable to update tokens, saved user is null!")
        }
    }

    fun saveLoggedInUser(loggedInUser: LoggedInUser?) {
        if (loggedInUser != null) {
            val userBytes = ObjectSerializer.serialize(loggedInUser)
            sharedPreferences
                .edit()
                .putString(PREF_KEY_LOGGED_IN_USER, userBytes.contentToString())
                .apply()
        } else {
            sharedPreferences
                .edit()
                .putString(PREF_KEY_LOGGED_IN_USER, null)
                .apply()
        }
    }

    fun readLoggedInUser(): LoggedInUser? {
        val userBytesString = sharedPreferences.getString(PREF_KEY_LOGGED_IN_USER, null)

        if (userBytesString != null) {
            // Converting token byte string to byte array
            // https://stackoverflow.com/a/19556636
            val split: List<String> = userBytesString.substring(1, userBytesString.length - 1).split(", ")
            val userBytes = ByteArray(split.size)
            for (i in split.indices) {
                userBytes[i] = split[i].toByte()
            }

            return ObjectSerializer.deserialize<LoggedInUser>(userBytes)
        }
        return null
    }

    fun isUsedCreditsExists(): Boolean {
        return readLoggedInUser()?.getTokens()?.isValid() ?: false
    }

    fun deleteUserCredits() {
        saveLoggedInUser(null)
    }

}