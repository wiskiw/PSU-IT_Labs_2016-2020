package com.psuteam.goodbooze.ui.support.adapter.pagination

import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.psuteam.goodbooze.ui.support.adapter.BindableViewHolder
import com.psuteam.goodbooze.ui.support.adapter.diffutil.DiffCallbackAdapter
import com.psuteam.goodbooze.ui.support.adapter.diffutil.RecyclerAdapterDiffUtil

abstract class LoadableAdapter<I : Any, VH : BindableViewHolder> :
    RecyclerView.Adapter<BindableViewHolder>(),
    DiffCallbackAdapter.ItemsDiffPredicate<Any> {

    companion object {
        private const val VIEW_TYPE_CONTENT_ITEM = 1
        private const val VIEW_TYPE_LOADING = -999

        private val LOADING_ITEM = LoadingItem()
    }

    private val diffCallbackAdapter: DiffCallbackAdapter<Any> = DiffCallbackAdapter(this)
    private val items = ArrayList<Any>()
    private val modifiableItems = ArrayList<Any>()

    var isLoading = false
        set(value) {
            if (field != value) {
                field = value
                if (value) {
                    addLoadingItem()
                } else {
                    removeLoadingItem()
                }
            }
        }

    override fun areItemsSame(objectA: Any?, objectB: Any?): Boolean {
        if (objectA is LoadingItem && objectB is LoadingItem) {
            return true
        } else {
            return if (objectA != null) objectA == objectB else objectB == null
        }
    }

    override fun areContentSame(objectA: Any?, objectB: Any?): Boolean {
        if (objectA is LoadingItem && objectB is LoadingItem) {
            return true
        } else {
            return if (objectA != null) objectA == objectB else objectB == null
        }
    }

    override fun getItemCount() = items.size

    private fun getItems(): ArrayList<Any> = items

    fun setContentItems(contentItems: List<I>) {
        modifiableItems.clear()
        modifiableItems.addAll(contentItems)
        if (isLoading) {
            modifiableItems.add(LOADING_ITEM)
        }
    }

    private fun get(position: Int): Any = items[position]

    private fun getLoadingItemIndex() = getItems().indexOfFirst { it is LoadingItem }

    private fun addLoadingItem() {
        modifiableItems.add(LOADING_ITEM)
    }

    private fun removeLoadingItem() {
        val loadingIndex = modifiableItems.indexOfFirst { it is LoadingItem }
        if (loadingIndex >= 0) {
            modifiableItems.removeAt(loadingIndex)
        }
    }

    fun applyAdapterContentChanges() {
        RecyclerAdapterDiffUtil.updateDataList(this, diffCallbackAdapter, items, modifiableItems, true)
    }

    @Suppress("LiftReturnOrAssignment")
    override fun getItemViewType(position: Int): Int {
        if (get(position) is LoadingItem) {
            return VIEW_TYPE_LOADING

        } else {
            val contentItemViewType = getContentItemViewType(position)
            if (contentItemViewType == VIEW_TYPE_LOADING) {
                throw IllegalStateException("Please use different from '$VIEW_TYPE_LOADING' view type!")
            }
            return contentItemViewType
        }
    }

    open fun getContentItemViewType(position: Int): Int = VIEW_TYPE_CONTENT_ITEM

    override fun onCreateViewHolder(root: ViewGroup, viewType: Int): BindableViewHolder {
        return when (viewType) {
            VIEW_TYPE_LOADING -> onCreateLoadingViewHolder(root)
            else -> onCreateContentItemViewHolder(root, viewType)
        }
    }

    abstract fun onCreateLoadingViewHolder(root: ViewGroup): BindableViewHolder

    abstract fun onCreateContentItemViewHolder(root: ViewGroup, viewType: Int): VH

    override fun onBindViewHolder(holder: BindableViewHolder, position: Int) {
        holder.bind(get(position))
    }

    class LoadingItem

}