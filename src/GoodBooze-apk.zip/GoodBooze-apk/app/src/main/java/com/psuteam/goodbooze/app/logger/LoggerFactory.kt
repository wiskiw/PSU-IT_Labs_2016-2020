package com.psuteam.goodbooze.app.logger

object LoggerFactory {

    private val logcatLogger = LogcatLogger()

    @JvmStatic
    fun getLogger(clazz: Class<*>): Logger {
        return logcatLogger
    }

}