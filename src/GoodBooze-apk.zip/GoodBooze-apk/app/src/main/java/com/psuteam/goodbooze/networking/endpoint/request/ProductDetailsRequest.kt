package com.psuteam.goodbooze.networking.endpoint.request

import com.psuteam.goodbooze.app.App
import com.psuteam.goodbooze.data.model.Address
import com.psuteam.goodbooze.data.model.Comment
import com.psuteam.goodbooze.data.model.ProductDetails
import com.psuteam.goodbooze.networking.endpoint.EndpointRequest
import com.psuteam.goodbooze.networking.proxy.Proxy
import com.psuteam.goodbooze.networking.proxy.ProxyException
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.util.*

class ProductDetailsRequest(
    private val productId: String
) : EndpointRequest<ProductDetails>() {

    override fun setup(app: App) {
        super.setup(app)

        params.apply {
            put("productId", productId)
        }
    }

    override fun getMethodName(): String = "productDetails"

    override fun getMethod(): Proxy.Method = Proxy.Method.GET

    override fun parseResponse(data: JSONObject): ProductDetails {
        try {
            val address = data.getJSONObject("address")

            return ProductDetails(
                id = data.getString("id"),
                title = data.getString("title"),
                date = Date(data.getLong("date")),
                imageId = data.getString("imageId"),
                address = Address(
                    address.getString("address"),
                    address.getDouble("latitude"),
                    address.getDouble("longitude")
                ),
                price = data.getDouble("price"),
                userId = data.getString("userId"),
                likes = data.getInt("likes"),
                description = data.getString("description"),
                isLiked = data.getBoolean("isLiked"),
                comments = getComments(data.getJSONArray("comments"))
            )

        } catch (e: JSONException) {
            throw ProxyException("Failed to parse JSON response.", e)
        }
    }

    @Throws(JSONException::class)
    private fun getComments(jsonArray: JSONArray): List<Comment> {
        val comments = mutableListOf<Comment>()
        for (i in 0 until jsonArray.length()) {
            val commentJson = jsonArray.getJSONObject(i)
            val comment = Comment(
                id = commentJson.getString("id"),
                userId = commentJson.getString("userId"),
                userName = commentJson.getString("userName"),
                imageId = commentJson.getString("imageId"),
                text = commentJson.getString("text")
            )
            comments.add(comment)
        }
        return comments
    }
}