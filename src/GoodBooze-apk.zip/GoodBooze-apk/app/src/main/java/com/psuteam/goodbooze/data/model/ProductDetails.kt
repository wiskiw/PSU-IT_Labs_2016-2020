package com.psuteam.goodbooze.data.model

import java.util.*

data class ProductDetails(
    val id: String,
    val title: String,
    val date: Date,
    val imageId: String,
    val address: Address,
    val price: Double,
    val userId: String,
    val likes: Int,
    val description: String,
    val isLiked: Boolean,
    val comments: List<Comment>
)
