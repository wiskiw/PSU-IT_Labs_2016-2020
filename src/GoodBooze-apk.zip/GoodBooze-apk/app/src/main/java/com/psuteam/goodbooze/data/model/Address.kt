package com.psuteam.goodbooze.data.model

data class Address(val name: String, val latitude: Double, val longitude: Double)