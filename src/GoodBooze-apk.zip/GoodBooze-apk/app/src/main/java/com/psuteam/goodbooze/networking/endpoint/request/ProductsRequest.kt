package com.psuteam.goodbooze.networking.endpoint.request

import com.psuteam.goodbooze.app.App
import com.psuteam.goodbooze.data.model.Address
import com.psuteam.goodbooze.data.model.Product
import com.psuteam.goodbooze.networking.endpoint.EndpointRequest
import com.psuteam.goodbooze.networking.proxy.Proxy
import com.psuteam.goodbooze.networking.proxy.ProxyException
import org.json.JSONException
import org.json.JSONObject
import java.util.*

class ProductsRequest(
    private val offset: Int,
    private val count: Int
) : EndpointRequest<List<Product>>() {

    override fun setup(app: App) {
        super.setup(app)

        params.apply {
            put("page", offset)
            put("count", count)
        }
    }

    override fun getMethodName(): String = "products"

    override fun getMethod(): Proxy.Method = Proxy.Method.GET

    override fun parseResponse(data: JSONObject): List<Product> {
        val products = mutableListOf<Product>()
        try {
            val productsJson = data.getJSONArray("products")

            for (i in 0 until productsJson.length()) {
                val productJson = productsJson.getJSONObject(i)
                products.add(parseProduct(productJson))
            }

        } catch (e: JSONException) {
            throw ProxyException("Failed to parse JSON response.", e)
        }

        return products
    }

    @Throws(JSONException::class)
    private fun parseProduct(productJson: JSONObject): Product {
        val address = productJson.getJSONObject("address")
        return Product(
            id = productJson.getString("id"),
            title = productJson.getString("title"),
            date = Date(productJson.getLong("date")),
            imageId = productJson.getString("imageId"),
            address = Address(
                address.getString("name"),
                address.getDouble("latitude"),
                address.getDouble("longitude")
            ),
            price = productJson.getDouble("price"),
            userId = productJson.getString("userId"),
            likes = productJson.getInt("likes")
        )

    }
}