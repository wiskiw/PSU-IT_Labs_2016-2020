package com.psuteam.goodbooze.networking.proxy.volley

import android.content.Context
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.VolleyError
import com.android.volley.toolbox.Volley
import com.psuteam.goodbooze.app.logger.LoggerFactory.getLogger
import com.psuteam.goodbooze.networking.proxy.Proxy
import com.psuteam.goodbooze.networking.proxy.ProxyResult
import com.psuteam.goodbooze.networking.proxy.UrlMethod
import org.json.JSONException
import org.json.JSONObject
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine

/**
 * [Proxy] implementation that use [Volley] to make HTTP calls for JSON objects.
 */
class VolleyJsonProxy(context: Context, private val isLogNetwork: Boolean) : Proxy<JSONObject> {

    companion object {
        private val LOGGER = getLogger(VolleyJsonProxy::class.java)
        private val VOLLEY_METHOD_MAPPING = mapOf(
            Pair(Proxy.Method.GET, Request.Method.GET),
            Pair(Proxy.Method.POST, Request.Method.POST)
        )
    }

    private val queue = Volley.newRequestQueue(context)

    override suspend fun send(
        method: Proxy.Method,
        urlMethod: UrlMethod,
        headers: Map<String, String>,
        params: JSONObject
    ): ProxyResult<JSONObject> {

        return suspendCoroutine { cont ->
            val request = MutableJsonRequest(
                convertToVolleyMethod(method),
                urlMethod.getUrl(),
                params,
                Response.Listener { cont.resume(onSuccess(it)) },
                Response.ErrorListener { cont.resume(onError(it)) }
            )
            request.headers = headers

            if (isLogNetwork) {
                LOGGER.debug(
                    "Sending Volley [$method] request to '${urlMethod.getUrl()}'\n" +
                            "headers: '$headers'\n" +
                            "params: '$params'"
                )
            }

            queue.add(request)
        }
    }

    private fun onSuccess(response: JSONObject): ProxyResult.Success<JSONObject> {
        // FixMe: Т к нет простого варианта вытащить HTTP status код при успешно запросе из Volley,
        // будем считать, что только все успешные запросы с кодом 200
        val code = 200

        if (isLogNetwork) {
            LOGGER.debug("Volley request success [code=${code}]: '$response'")
        }

         return ProxyResult.Success(code, response)
    }

    private fun onError(volleyError: VolleyError): ProxyResult.Error<JSONObject> {
        val code = volleyError.networkResponse.statusCode
        val responseBody = volleyError.networkResponse.data.toString(Charsets.UTF_8)

        if (isLogNetwork) {
            LOGGER.error("Volley request failed [code=${code}]: '${responseBody}'!", volleyError)
        }

        return try {
            val data = JSONObject(responseBody)
            ProxyResult.Error(code, data, volleyError)
        } catch (e: JSONException) {
            ProxyResult.Error(code, JSONObject(), e)
        }
    }

    private fun convertToVolleyMethod(method: Proxy.Method): Int = VOLLEY_METHOD_MAPPING[method] ?: throw IllegalStateException()
}