package com.psuteam.goodbooze.networking

interface ErrorIndicator {

    fun showError(message: String, isRetryAllow: Boolean = true)

    fun hide()

    val isVisible: Boolean

    fun setRetryListener(listener: RetryListener?)

    interface RetryListener {
        fun onRetry()
    }

}