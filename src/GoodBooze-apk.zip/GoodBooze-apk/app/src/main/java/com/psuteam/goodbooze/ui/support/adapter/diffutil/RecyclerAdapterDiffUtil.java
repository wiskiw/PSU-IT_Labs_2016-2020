package com.psuteam.goodbooze.ui.support.adapter.diffutil;

import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.psuteam.goodbooze.app.utils.Utils;
import com.psuteam.goodbooze.ui.support.adapter.ModifiableRecyclerAdapter;

import java.util.List;

/**
 * Утилиты для использования {@link DiffUtil} в {@link RecyclerView.Adapter}
 *
 * Created by Andrey Yablonsky on 21.05.19.
 */
public final class RecyclerAdapterDiffUtil {

    /**
     * Устанавливает новый список элементов с использованием {@link DiffUtil} в #recyclerAdapter.
     * <p>
     * Избавляет от необходимости вызова метода {@link RecyclerView.Adapter#notifyDataSetChanged()}
     * или ручного просчета изменившихся элементов списка при установке нового списка элементов.
     * </p>
     *
     * @param recyclerAdapter         Адаптер, элементы которого нужно обновить.
     * @param diffCallbackAdapter Адаптер {@link DiffUtil.Callback} для работы c элементами #recyclerAdapter.
     * @param newItems                Новый(измененный) список элементов.
     * @param detectMoves             Определяет необходимость обнаружения перемещенных элементов списка.
     *                                Используйте {@code false} для улучшения производительности.
     * @param <I>                     Тип элемент.
     * @param <A>                     Адаптер. Расширяет {@link RecyclerView.Adapter}
     *                                и реализует {@link ModifiableRecyclerAdapter<I>}
     */
    public static <I, A extends ModifiableRecyclerAdapter<I, ? extends RecyclerView.ViewHolder>>
    void updateDataList(A recyclerAdapter, DiffCallbackAdapter<I> diffCallbackAdapter, List<I> newItems, boolean detectMoves) {

        updateDataList(recyclerAdapter, diffCallbackAdapter, recyclerAdapter.getItems(), newItems, detectMoves);
    }

    public static <I, A extends RecyclerView.Adapter> void updateDataList(
            A recyclerAdapter,
            DiffCallbackAdapter<I> diffCallbackAdapter,
            List<I> adapterItems,
            List<I> newItems,
            boolean detectMoves
    ) {

        Utils.checkNotNull(recyclerAdapter, "Recycler adapter must not be null!");
        Utils.checkNotNull(diffCallbackAdapter, "DiffUtils callback adapter must not be null!");
        Utils.checkNotNull(newItems, "Item's list must not be null!");

        diffCallbackAdapter.setOldList(adapterItems);
        diffCallbackAdapter.setNewList(newItems);

        DiffUtil.DiffResult diffResult = DiffUtil.calculateDiff(diffCallbackAdapter, detectMoves);

        adapterItems.clear();
        adapterItems.addAll(newItems);

        diffResult.dispatchUpdatesTo(recyclerAdapter);
    }

}
