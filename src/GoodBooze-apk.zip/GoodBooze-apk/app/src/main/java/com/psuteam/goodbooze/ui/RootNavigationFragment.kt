package com.psuteam.goodbooze.ui

import android.content.Context
import android.os.Bundle
import android.view.View
import androidx.activity.addCallback
import androidx.fragment.app.Fragment
import androidx.navigation.NavController
import androidx.navigation.fragment.findNavController
import com.psuteam.goodbooze.app.App
import com.psuteam.goodbooze.app.logger.LoggerFactory

open class RootNavigationFragment : Fragment() {

    companion object {
        private val LOGGER = LoggerFactory.getLogger(RootNavigationFragment::class.java)
    }

    protected lateinit var app : App
    protected lateinit var navController: NavController
        private set

    override fun onAttach(context: Context) {
        super.onAttach(context)

        app = context.applicationContext as App
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        navController = findNavController()
    }

}