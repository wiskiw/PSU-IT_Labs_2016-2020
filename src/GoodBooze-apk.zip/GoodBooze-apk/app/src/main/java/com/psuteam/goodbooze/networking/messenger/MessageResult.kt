package com.psuteam.goodbooze.networking.messenger

sealed class MessageResult<out T: Any> {

    data class Success<out T : Any>(val data: T) : MessageResult<T>()
    data class AuthError(val message: String, val exception: Exception) : MessageResult<Nothing>()
    data class Error(val code: Int, val message: String, val exception: Exception) : MessageResult<Nothing>()

    override fun toString(): String {
        return when (this) {
            is Success<T> -> "Success[data=$data]"
            is AuthError -> "Error[message='$message', exception=$exception]"
            is Error -> "Error[code=$code, message='$message', exception=$exception]"
        }
    }
}
