package com.psuteam.goodbooze.networking.proxy

import org.json.JSONObject

/**
 * Describes how to interact with the server.
 */
interface Proxy<R : Any> {

    enum class Method {
        GET,
        POST,
    }

    suspend fun send(
        method: Method,
        urlMethod: UrlMethod,
        headers: Map<String, String>,
        params: JSONObject
    ): ProxyResult<R>

}