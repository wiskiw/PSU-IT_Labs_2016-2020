package com.psuteam.goodbooze.data.storage

import android.content.Context
import com.psuteam.goodbooze.data.storage.reader.JsonAssetReader
import com.psuteam.goodbooze.data.storage.reader.PropertyReader

/**
 * Класс для предоставления доступа к хранилицам приложения
 *
 * Created by Andrey Yablonsky on 16.02.2019.
 */
class DataStorageProvider(context: Context) {

    companion object {
        private const val APP_PROPERTY_FILENAME = "config.properties"
        private const val APP_SHARED_PREFERENCES_FILE = "application-preferences"
    }

    val appPreferenceStorage: AppPreferenceStorage
    val userStorage: UserStorage
    val jsonAssetReader: JsonAssetReader = JsonAssetReader(context)

    init {
        val sharedPreferences = context.getSharedPreferences(APP_SHARED_PREFERENCES_FILE, Context.MODE_PRIVATE)
        val propertyReader = PropertyReader(context, APP_PROPERTY_FILENAME)

        appPreferenceStorage = AppPreferenceStorage(sharedPreferences, propertyReader)
        userStorage = UserStorage(sharedPreferences)
    }
}