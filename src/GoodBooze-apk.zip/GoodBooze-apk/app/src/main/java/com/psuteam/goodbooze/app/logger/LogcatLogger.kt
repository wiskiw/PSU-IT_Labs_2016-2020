package com.psuteam.goodbooze.app.logger

import android.util.Log

class LogcatLogger : Logger {

    companion object {
        private const val TAG = "GoodBooze"
    }

    override fun debug(message: String) {
        Log.d(TAG, message)
    }

    override fun warn(message: String) {
        Log.w(TAG, message)
    }

    override fun warn(message: String, exception: Exception?) {
        Log.w(TAG, message, exception)
    }

    override fun error(message: String) {
        Log.e(TAG, message)
    }

    override fun error(message: String, exception: Exception?) {
        Log.e(TAG, message, exception)
    }

}