package com.psuteam.goodbooze.data.model

import java.util.*

data class Product(
    val id: String,
    val title: String,
    val date: Date,
    val imageId: String,
    val address: Address,
    val price: Double,
    val userId: String,
    val likes: Int
)
