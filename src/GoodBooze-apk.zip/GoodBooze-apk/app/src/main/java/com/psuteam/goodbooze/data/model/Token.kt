package com.psuteam.goodbooze.data.model

import java.io.Serializable

data class Token(val token: String, val expiredDate : Long) : Serializable{

    fun isValid() = System.currentTimeMillis() <= expiredDate

}