package com.psuteam.goodbooze.data.storage.reader;

import android.content.Context;
import android.content.res.AssetManager;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * Класс для чтения значений из .property файла
 *
 * Created by Andrey Yablonsky on 16.02.2019.
 *
 * @author Andrey Yablonsky
 */
public class PropertyReader {

    private Properties properties;

    /**
     * @param context  контекст приложения
     * @param filename название .property файла например, application.properties
     */
    public PropertyReader(Context context, final String filename) {
        this.properties = new Properties();
        load(context, filename);
    }

    private void load(Context context, final String filename) {
        AssetManager assetManager = context.getAssets();
        try {
            InputStream inputStream = assetManager.open(filename);
            properties.load(inputStream);
        }
        catch (IOException e) {
            throw new IllegalArgumentException(String.format("Cannot send properties from '%s'", filename), e);
        }
    }

    /**
     * Чтение значения по ключу {@code key} из .property файла
     *
     * @param key ключ для чтения значения
     * @return значение для ключа key
     * @throws IllegalArgumentException если файл не содержит значения для ключа {@code key}
     */
    public String getString(final String key) throws IllegalArgumentException {
        if (properties.containsKey(key)) {
            return properties.getProperty(key);
        } else {
            throw new IllegalArgumentException(String.format("Properties file does not contains property for '%s'", key));
        }
    }

    public Boolean getBool(String key) {
        return Boolean.valueOf(getString(key));
    }

    public Integer getInt(String key) {
        String value = getString(key);

        try {
            return Integer.valueOf(value);
        }
        catch (NumberFormatException exception) {
            throw new IllegalArgumentException(
                String.format("Expected Integer value for '%s', but '%s' found!", key, value), exception);
        }
    }

}
