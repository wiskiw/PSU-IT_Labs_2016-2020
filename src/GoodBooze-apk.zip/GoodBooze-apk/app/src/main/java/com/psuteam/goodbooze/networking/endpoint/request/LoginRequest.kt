package com.psuteam.goodbooze.networking.endpoint.request

import com.psuteam.goodbooze.app.App
import com.psuteam.goodbooze.data.model.LoggedInUser
import com.psuteam.goodbooze.data.model.Token
import com.psuteam.goodbooze.networking.endpoint.EndpointRequest
import com.psuteam.goodbooze.networking.proxy.Proxy
import com.psuteam.goodbooze.networking.proxy.ProxyException
import org.json.JSONException
import org.json.JSONObject

/**
 * Sample implementation of login request
 */
class LoginRequest(
    private val login: String,
    private val password: String
) : EndpointRequest<LoggedInUser>() {

    companion object {
        private const val PARAM_KEY_LOGIN = "login"
        private const val PARAM_KEY_PASSWORD = "password"

        private const val RESPONSE_KEY_TOKEN = "token"
        private const val RESPONSE_KEY_EXPIRATION = "expiration"
    }

    override fun setup(app: App) {
        super.setup(app)

        params.apply {
            put(PARAM_KEY_LOGIN, login)
            put(PARAM_KEY_PASSWORD, password)
        }
    }

    override fun getMethodName(): String = "login"

    override fun getMethod(): Proxy.Method = Proxy.Method.GET

    override fun parseResponse(data: JSONObject): LoggedInUser {
        try {
            val id = data.getString("id")
            val name = data.getString("name")
            val login = data.getString("login")
            val accessToken = getToken(data, "accessToken")
            val refreshToken = getToken(data, "refreshToken")
            val userRole = getUserRole(data)
            return LoggedInUser(id, name, login, accessToken, refreshToken, userRole)

        } catch (e: JSONException) {
            throw ProxyException("Failed to parse JSON response.", e)
        }
    }

    @Throws(JSONException::class)
    private fun getToken(data: JSONObject, tokenKey: String): Token {
        val tokenJson = data.getJSONObject(tokenKey)
        return Token(tokenJson.getString(RESPONSE_KEY_TOKEN), tokenJson.getLong(RESPONSE_KEY_EXPIRATION))
    }

    @Throws(JSONException::class)
    private fun getUserRole(data: JSONObject): LoggedInUser.UserRole {
        val userRoleString = data.optString("user_role", "")
        return when (userRoleString) {
            "moderator" -> LoggedInUser.UserRole.MODERATOR
            else -> LoggedInUser.UserRole.REGULAR
        }
    }

}