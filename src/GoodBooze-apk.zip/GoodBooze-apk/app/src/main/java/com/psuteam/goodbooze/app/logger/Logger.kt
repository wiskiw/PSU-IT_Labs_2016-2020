package com.psuteam.goodbooze.app.logger

import java.lang.Exception

interface Logger {

    fun debug(message: String)

    fun warn(message: String)

    fun warn(message: String, exception: Exception?)

    fun error(message: String)

    fun error(message: String, exception: Exception?)

}