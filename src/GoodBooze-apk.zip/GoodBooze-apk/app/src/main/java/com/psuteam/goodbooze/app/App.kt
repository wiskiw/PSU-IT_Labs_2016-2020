package com.psuteam.goodbooze.app

import android.app.Application
import com.psuteam.goodbooze.app.logger.LoggerFactory
import com.psuteam.goodbooze.data.storage.DataStorageProvider
import com.psuteam.goodbooze.data.mock.MockJsonResponseReader
import com.psuteam.goodbooze.data.storage.AppPreferenceStorage
import com.psuteam.goodbooze.networking.proxy.Proxy
import com.psuteam.goodbooze.networking.proxy.stub.StubJsonProxy
import com.psuteam.goodbooze.networking.proxy.volley.VolleyJsonProxy
import org.json.JSONObject

class App : Application() {

    private val LOGGER = LoggerFactory.getLogger(App::class.java)

    lateinit var preferences: AppPreferenceStorage
    lateinit var dataStorageProvider: DataStorageProvider

    private lateinit var networkJsonProxy: Proxy<JSONObject>
    private lateinit var stubJsonProxy: StubJsonProxy

    public var counter = 0

    override fun onCreate() {
        super.onCreate()
        dataStorageProvider = DataStorageProvider(this)
        preferences = dataStorageProvider.appPreferenceStorage

        setupProxy()
    }

    private fun setupProxy() {
        val isLogNetwork = preferences.readIsLogNetwork()
        networkJsonProxy = VolleyJsonProxy(this, isLogNetwork)
        stubJsonProxy = StubJsonProxy(isLogNetwork, MockJsonResponseReader(dataStorageProvider.jsonAssetReader))
    }

    fun getJsonProxy(responseId: String? = null): Proxy<JSONObject> {
        if (preferences.readIsUseStub()) {
            stubJsonProxy.responseId = responseId
            return stubJsonProxy
        } else {
            return networkJsonProxy
        }
    }
}