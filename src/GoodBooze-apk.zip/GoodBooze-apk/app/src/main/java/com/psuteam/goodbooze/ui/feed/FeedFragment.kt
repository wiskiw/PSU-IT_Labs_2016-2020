package com.psuteam.goodbooze.ui.feed

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.psuteam.goodbooze.R
import com.psuteam.goodbooze.app.logger.LoggerFactory
import com.psuteam.goodbooze.data.model.Product
import com.psuteam.goodbooze.networking.endpoint.request.ProductsRequest
import com.psuteam.goodbooze.networking.messenger.AuthedMessenger
import com.psuteam.goodbooze.networking.messenger.MessageResult
import com.psuteam.goodbooze.ui.LoggedInFragment
import com.psuteam.goodbooze.ui.ScreenUiController
import com.psuteam.goodbooze.ui.support.adapter.pagination.PaginationListener
import kotlinx.android.synthetic.main.fragment_feed.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

/**
 * A [Fragment] for Drinks feed screen.
 */
class FeedFragment : LoggedInFragment() {

    companion object {
        private val LOGGER = LoggerFactory.getLogger(FeedFragment::class.java)
        private const val PAGE_SIZE = 4
        private const val PAGE_COUNT = 2
    }

    private lateinit var productAdapter: FeedRecyclerAdapter

    private var isLoading: Boolean = false
    private var isLastPage: Boolean = false

    private val products = mutableListOf<Product>()
    private var page: Int = 0

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_feed, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        screenUiController.setTitle(getString(R.string.feed_title))
        screenUiController.setDrawerUser(name = loggedInUser.name, login = loggedInUser.login)
        screenUiController.changeScreenStyle(ScreenUiController.ScreenStyle.AUTHED_TOOLBAR)

        val linearLayoutManager = LinearLayoutManager(context)

        productAdapter = FeedRecyclerAdapter()
        productAdapter.clickListeners = ProductClickListener()
        feedRecycler.layoutManager = linearLayoutManager
        feedRecycler.adapter = productAdapter
        feedRecycler.addOnScrollListener(ProductPaginationListener(linearLayoutManager))


        if (products.isEmpty()) {
            loadMore(0, PAGE_SIZE)
        } else {
            productAdapter.setProducts(products)
            productAdapter.applyAdapterContentChanges()
        }
    }

    private fun loadMore(offset: Int, count: Int) {
        GlobalScope.launch(Dispatchers.Main) {

            changeLoadingState(true)
            productAdapter.applyAdapterContentChanges()

            loadProducts(offset, count)
            changeLoadingState(false)

            productAdapter.applyAdapterContentChanges()
        }
    }

    private fun changeLoadingState(isLoading: Boolean) {
        this.isLoading = isLoading
        productAdapter.isLoading = isLoading
    }

    private suspend fun loadProducts(offset: Int, count: Int) {
        val request = ProductsRequest(offset, count)

        if (page < PAGE_COUNT) {
            isLastPage = false
            val mockFileId = page.toString()
            page++

            val result = AuthedMessenger(app, app.getJsonProxy(mockFileId), request)
                .apply { navController = super.navController }
                .send()

            if (result is MessageResult.Success) {
                products.addAll(result.data)
                productAdapter.setProducts(products)
            }

        } else {
            isLastPage = true
        }

    }

    inner class ProductClickListener : FeedRecyclerAdapter.ClickListeners {

        override fun onClick(product: Product) {
            val action = FeedFragmentDirections.actionFeedFragmentToDetailsFragment(product.id)
            navController.navigate(action)
        }

    }

    inner class ProductPaginationListener(layoutManager: LinearLayoutManager) : PaginationListener(layoutManager, PAGE_SIZE) {

        override val isLastPage: Boolean
            get() = this@FeedFragment.isLastPage

        override val isLoading: Boolean
            get() = this@FeedFragment.isLoading

        override fun loadMoreItems(offset: Int, count: Int) {
            loadMore(offset, count)
        }
    }

}