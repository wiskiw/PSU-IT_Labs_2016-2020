package com.psuteam.goodbooze.ui

import com.psuteam.goodbooze.data.model.LoggedInUser

interface LoggedInFragmentContainer {

    fun getScreenUiController() : ScreenUiController

    fun getLoggedInUser(): LoggedInUser

}