package com.psuteam.goodbooze.ui.profile

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.navArgs
import com.bumptech.glide.Glide
import com.psuteam.goodbooze.R
import com.psuteam.goodbooze.app.logger.LoggerFactory
import com.psuteam.goodbooze.data.model.Profile
import com.psuteam.goodbooze.networking.ErrorIndicator
import com.psuteam.goodbooze.networking.endpoint.request.ProductDetailsRequest
import com.psuteam.goodbooze.networking.endpoint.request.ProfileRequest
import com.psuteam.goodbooze.networking.messenger.AuthedMessenger
import com.psuteam.goodbooze.networking.messenger.MessageResult
import com.psuteam.goodbooze.ui.LoggedInFragment
import com.psuteam.goodbooze.ui.ScreenUiController
import kotlinx.android.synthetic.main.fragment_details.*
import kotlinx.android.synthetic.main.fragment_details.descriptionText
import kotlinx.android.synthetic.main.fragment_details.errorPanel
import kotlinx.android.synthetic.main.fragment_details.progressPanel
import kotlinx.android.synthetic.main.fragment_profile.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class ProfileFragment : LoggedInFragment() {

    companion object {
        private val LOGGER = LoggerFactory.getLogger(ProfileFragment::class.java)
        private const val BIRTHDAY_FORMAT = "dd.mm.yyyy"
    }

    private val args: ProfileFragmentArgs by navArgs()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_profile, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        screenUiController.setTitle(getString(R.string.profile_title))
        screenUiController.changeScreenStyle(ScreenUiController.ScreenStyle.NOT_AUTHED_FULL_SCREEN)

        errorPanel.setRetryListener(RetryListener())

        loadProfile(args.profileId)
    }

    private fun loadProfile(profileId: String) {
        GlobalScope.launch(Dispatchers.Main) {

            val mockFileId = profileId

            val result = AuthedMessenger(app, app.getJsonProxy(mockFileId), ProfileRequest(profileId))
                .apply {
                    navController = super.navController
                    errorIndicator = errorPanel
                    progressIndicator = progressPanel
                }
                .send()

            if (result is MessageResult.Success) {
                bind(result.data)
            }
        }
    }

    private fun bind(profile: Profile) {
        Glide.with(profileImage.context)
            .load(profile.imageId)
            .centerCrop()
            .placeholder(R.drawable.ic_placeholder)
            .into(profileImage)

        nameText.text = profile.name
        emailText.text = profile.email
        birthdayText.text = SimpleDateFormat(BIRTHDAY_FORMAT, Locale.getDefault()).format(profile.birthday)
        productsCounterText.text = profile.productsCount.toString()
        bioText.text = profile.bio

    }

    inner class RetryListener : ErrorIndicator.RetryListener {
        override fun onRetry() {

            loadProfile(args.profileId)
        }
    }
}