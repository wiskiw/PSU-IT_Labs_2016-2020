package com.psuteam.goodbooze.networking.endpoint.request

import com.psuteam.goodbooze.app.App
import com.psuteam.goodbooze.data.model.Profile
import com.psuteam.goodbooze.networking.endpoint.EndpointRequest
import com.psuteam.goodbooze.networking.proxy.Proxy
import com.psuteam.goodbooze.networking.proxy.ProxyException
import org.json.JSONException
import org.json.JSONObject
import java.util.*

class ProfileRequest(
    private val userId: String
) : EndpointRequest<Profile>() {

    override fun setup(app: App) {
        super.setup(app)

        params.apply {
            put("id", userId)
        }
    }

    override fun getMethodName(): String = "profile"

    override fun getMethod(): Proxy.Method = Proxy.Method.GET

    override fun parseResponse(data: JSONObject): Profile {
        try {
            return Profile(
                id = data.getString("id"),
                name = data.getString("name"),
                email = data.getString("email"),
                imageId = data.getString("imageId"),
                birthday = Date(data.getLong("birthday")),
                bio = data.getString("bio"),
                productsCount = data.getInt("productsCount")
            )
        } catch (e: JSONException) {
            throw ProxyException("Failed to parse JSON response.", e)
        }
    }

}