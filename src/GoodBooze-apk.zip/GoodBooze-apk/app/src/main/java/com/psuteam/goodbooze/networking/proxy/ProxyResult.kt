package com.psuteam.goodbooze.networking.proxy

sealed class ProxyResult<T: Any> {

    data class Success<T : Any>(val code: Int, val data: T) : ProxyResult<T>()
    data class Error<T : Any>(val code: Int, val data: T, val exception: Exception) : ProxyResult<T>()

    override fun toString(): String {
        return when (this) {
            is Success<T> -> "Success[data=$data]"
            is Error<T> -> "Error[code=$code, data=$data, exception=$exception]"
        }
    }
}
