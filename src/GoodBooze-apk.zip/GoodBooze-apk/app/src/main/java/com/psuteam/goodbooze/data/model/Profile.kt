package com.psuteam.goodbooze.data.model

import java.util.*

data class Profile(
    val id: String,
    val name: String,
    val email: String,
    val imageId: String,
    val birthday: Date,
    val bio: String,
    val productsCount: Int
)