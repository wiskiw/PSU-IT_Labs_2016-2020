package com.psuteam.goodbooze.ui.support.adapter.diffutil;

import java.util.ArrayList;
import java.util.List;

import androidx.recyclerview.widget.DiffUtil;

/**
 * Адаптер {@link DiffUtil.Callback} для работы со списками. Инкапсулирует логику работы со списками.
 *
 * @author Q-ANY
 */
public class DiffCallbackAdapter<T> extends DiffUtil.Callback {

    private ItemsDiffPredicate<T> diffPredicate;

    private List<T> oldList = new ArrayList<>();
    private List<T> newList = new ArrayList<>();

    /**
     * Основной конструктор адаптера. Принимает предикаты для сравнения элементов и их содержимого
     *

     */
    public DiffCallbackAdapter(ItemsDiffPredicate<T> diffPredicate) {
        this.diffPredicate = diffPredicate;
    }

    public void setDiffPredicate(ItemsDiffPredicate<T> diffPredicate) {
        this.diffPredicate = diffPredicate;
    }

    public void setOldList(List<T> oldList) {
        this.oldList = oldList;
    }

    public void setNewList(List<T> newList) {
        this.newList = newList;
    }

    @Override
    public int getOldListSize() {
        return oldList.size();
    }

    @Override
    public int getNewListSize() {
        return newList.size();
    }

    @Override
    public boolean areItemsTheSame(int oldPos, int newPos) {
        if (diffPredicate != null) {
            return diffPredicate.areItemsSame(oldList.get(oldPos), newList.get(newPos));
        } else {
            return false;
        }
    }

    @Override
    public boolean areContentsTheSame(int oldPos, int newPos) {
        if (diffPredicate != null) {
            return diffPredicate.areContentSame(oldList.get(oldPos), newList.get(newPos));
        } else {
            return false;
        }
    }

    public interface ItemsDiffPredicate<O> {

        /**
         * DiffUtil uses this equals predicate to decide whether two object represent the same Item.
         * For example, if your items have unique ids, this method should check their id equality.
         *
         * @param objectA один из объектов для сравнения
         * @param objectB второй из объектов для сравнения
         * @return {@code true}, если #objectA идентичен #objectB
         */
        boolean areItemsSame(O objectA, O objectB);

        /**
         * DiffUtil uses this equals predicate to check equality instead of equals(Object)
         * so that you can change its behavior depending on your UI.
         * For example, if you are using DiffUtil with a RecyclerView.Adapter,
         *
         * @param objectA один из объектов для сравнения
         * @param objectB второй из объектов для сравнения
         * @return {@code true}, если #objectA идентичен #objectB
         */
        boolean areContentSame(O objectA, O objectB);

    }
}
