package com.psuteam.goodbooze.app.utils

import com.psuteam.goodbooze.app.logger.LoggerFactory.getLogger
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.ObjectInputStream
import java.io.ObjectOutputStream

object ObjectSerializer {

    private val LOGGER = getLogger(ObjectSerializer::class.java)

    fun serialize(any: Any?): ByteArray {
        if (any === null) {
            return ByteArray(0)
        }

        val baos = ByteArrayOutputStream()
        val os = ObjectOutputStream(baos)
        os.writeObject(any)
        os.close()

        return baos.toByteArray()
    }

    @Throws(IllegalArgumentException::class)
    fun <T> deserialize(byteArray: ByteArray): T? {
        if (byteArray.isEmpty()) {
            return null
        }

        val bais = ByteArrayInputStream(byteArray)
        val ois = ObjectInputStream(bais)

        try {
            return ois.readObject() as T?
        } catch (e: ClassCastException) {
            LOGGER.error("Deserializes bytes cast failed!", e)
            return null
        }

    }

}