package com.psuteam.goodbooze.app.utils

import android.app.Application
import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.ImageView
import androidx.annotation.ColorRes
import androidx.annotation.IdRes
import androidx.annotation.LayoutRes
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat


/**
 * Утилиты для работы с UI
 *
 * @author Andrey Yablonsky
 */
object UiUtils {

    /**
     * Биндит view-элемент формы [view] с идентификатором ресурса [resId]
     */
    fun <T : View> bind(view: View, @IdRes resId: Int): T {
        @Suppress("UNCHECKED_CAST")
        return view.findViewById(resId) as T
    }

    @JvmStatic
    fun inflate(context: Context, @LayoutRes resId: Int): View {
        return View.inflate(context, resId, null)
    }

    @JvmStatic
    fun inflate(parent: ViewGroup, @LayoutRes resId: Int): View {
        return LayoutInflater.from(parent.context).inflate(resId, parent, false)
    }

    /**
     * Создает view и присоединяет его в качестве child указанной компоненты
     *
     * @param context Context android контекст
     * @param layoutId идентификатор лейаута, используемый для создания нового view
     * @param root ViewGroup к которой будет добавлен View.
     */
    @JvmStatic
    fun inflateToParent(context: Context, layoutId: Int, root: ViewGroup): View {
        return LayoutInflater.from(context).inflate(layoutId, root, true)
    }

    /**
     * Sets visibility of views.
     * @param visible [Boolean.true] if views should be visible
     * @param views View[] views
     */
    @JvmStatic
    fun setVisibility(visible: Boolean, vararg views: View) {
        for (view in views) {
            view.visibility = if (visible) View.VISIBLE else View.GONE
        }
    }

    /**
     * Sets visibility of views.
     * Null-safety.
     * @param visible [Boolean.true] if views should be visible
     * @param views View[] views
     */
    @JvmStatic
    fun setVisibilityContent(visible: Boolean, vararg views: View?) {
        for (view in views) {
            view?.visibility = if (visible) View.VISIBLE else View.INVISIBLE
        }
    }

    /**
     * Change activity toolbar left-back button visibility.
     *
     * Do not set on click listener for button! Override [AppCompatActivity.onSupportNavigateUp] for it
     */
    @JvmStatic
    fun changeToolbarBackButtonVisibility(activity: AppCompatActivity, enable: Boolean) {
        activity.supportActionBar?.apply {
            setDisplayHomeAsUpEnabled(enable)
            setDisplayShowHomeEnabled(enable)
        }
    }

    /**
     * Возвращает зависимое от числительного существительное в нужном склонении
     *
     * @param number число, определяющее склонение
     * @param context Контекст для доступа к ресурсам
     * @param singleId id текст для единственного числа
     * @param shortId id текст для чисел в диапазоне от двух до четырех
     * @param multipleId id текст для чисел больше пяти
     */
    @JvmStatic
    fun conjugateText(number: Int, context: Context, singleId: Int, shortId: Int, multipleId: Int, vararg params: Any): String {
        return if (number in 5..20) {
            context.getString(multipleId, *params)
        } else {
            when (number % 10) {
                in 2..4 -> context.getString(shortId, *params)
                1 -> context.getString(singleId, *params)
                else -> context.getString(multipleId, *params)
            }
        }
    }

    /**
     * Форсирует отображение клавиатуры для данного [View]
     *
     * @param context [Context] контекст выполнения
     * @param view [View] для отображения клавиатуры
     */
    @JvmStatic
    fun showKeyboard(context: Context, view: View) {
        val inputManager = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        inputManager.showSoftInput(view, 0)
    }

    /**
     * Скрывает отображение клавиатуры для данного [View]
     *
     * @param context [Context] контекст выполнения
     * @param view [View] для отображения клавиатуры. Do nothing if NULL
     */
    @JvmStatic
    fun hideKeyboard(context: Context, view: View?) {
        if (view == null){
            return
        }

        val inputManager = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        inputManager.hideSoftInputFromWindow(view.windowToken, 0)
    }

    /**
     * Перезапускает приложение
     */
    @JvmStatic
    fun restartApp(application: Application) {
        val appIntent = application.packageManager.getLaunchIntentForPackage(application.packageName)!!
        appIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
        appIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        appIntent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION)

        application.startActivity(appIntent)
    }

    /**
     * Заменяет цвет изображения в [imageView] на [colorRes]
     * @param colorRes идентификатор ресурса с цветом
     */
    @JvmStatic
    fun setImageTint(imageView: ImageView, @ColorRes colorRes: Int) {
        imageView.setColorFilter(ContextCompat.getColor(imageView.context, colorRes), android.graphics.PorterDuff.Mode.MULTIPLY)
    }

}