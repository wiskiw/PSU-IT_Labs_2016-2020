package com.psuteam.goodbooze.ui.editprofile

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.navArgs
import com.psuteam.goodbooze.R
import com.psuteam.goodbooze.app.logger.LoggerFactory
import com.psuteam.goodbooze.data.model.Profile
import com.psuteam.goodbooze.networking.ErrorIndicator
import com.psuteam.goodbooze.networking.endpoint.request.EditProfileRequest
import com.psuteam.goodbooze.networking.endpoint.request.ProfileRequest
import com.psuteam.goodbooze.networking.messenger.AuthedMessenger
import com.psuteam.goodbooze.networking.messenger.MessageResult
import com.psuteam.goodbooze.ui.LoggedInFragment
import com.psuteam.goodbooze.ui.ScreenUiController
import kotlinx.android.synthetic.main.fragment_details.errorPanel
import kotlinx.android.synthetic.main.fragment_details.progressPanel
import kotlinx.android.synthetic.main.fragment_edit_profile.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

class EditProfileFragment : LoggedInFragment() {

    companion object {
        private val LOGGER = LoggerFactory.getLogger(EditProfileFragment::class.java)
    }

    private val args: EditProfileFragmentArgs by navArgs()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_edit_profile, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        screenUiController.setTitle(getString(R.string.edit_profile_title))
        screenUiController.changeScreenStyle(ScreenUiController.ScreenStyle.AUTHED_TOOLBAR_CHILD)

        errorPanel.setRetryListener(RetryListener())

        loadProfile(args.profileId)
    }

    private fun loadProfile(profileId: String) {
        GlobalScope.launch(Dispatchers.Main) {

            val mockFileId = profileId

            val result = AuthedMessenger(app, app.getJsonProxy(mockFileId), ProfileRequest(profileId))
                .apply {
                    navController = super.navController
                    errorIndicator = errorPanel
                    progressIndicator = progressPanel
                }
                .send()

            if (result is MessageResult.Success) {
                bind(result.data)
            }
        }
    }

    private fun bind(profile: Profile) {
        nameEdit.setText(profile.name)
        emailEdit.setText(profile.email)
        bioEdit.setText(profile.bio)
        imageIdEdit.setText(profile.imageId)

        saveButton.setOnClickListener {
            save(
                nameEdit.text.toString(),
                emailEdit.text.toString(),
                bioEdit.text.toString(),
                imageIdEdit.text.toString()
            )
        }
    }

    private fun save(name: String, email: String, bio: String, imageId: String) {
        GlobalScope.launch(Dispatchers.Main) {

            val request = EditProfileRequest(args.profileId, name, email, bio, imageId)
            val result = AuthedMessenger(app, app.getJsonProxy(), request)
                .apply {
                    navController = super.navController
                    errorIndicator = errorPanel
                    progressIndicator = progressPanel
                }
                .send()

            if (result is MessageResult.Success) {
                navController.popBackStack()
            }
        }
    }

    inner class RetryListener : ErrorIndicator.RetryListener {
        override fun onRetry() {

            loadProfile(args.profileId)
        }
    }
}