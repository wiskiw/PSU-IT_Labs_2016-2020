package com.psuteam.goodbooze.data.model

data class CreateProduct(
    val title: String,
    val imageId: String,
    val address: Address,
    val description: String,
    val price: Double,
    val userId: String
)
