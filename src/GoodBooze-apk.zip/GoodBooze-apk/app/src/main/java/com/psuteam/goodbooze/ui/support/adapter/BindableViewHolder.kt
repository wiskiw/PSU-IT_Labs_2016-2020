package com.psuteam.goodbooze.ui.support.adapter

import android.view.View
import androidx.recyclerview.widget.RecyclerView

abstract class BindableViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

    open fun <I> bind(item: I) {

    }

}