package com.psuteam.goodbooze.networking.proxy.stub

import com.android.volley.VolleyError
import com.psuteam.goodbooze.app.logger.LoggerFactory.getLogger
import com.psuteam.goodbooze.data.mock.MockJsonResponseReader
import com.psuteam.goodbooze.networking.proxy.Proxy
import com.psuteam.goodbooze.networking.proxy.ProxyResult
import com.psuteam.goodbooze.networking.proxy.UrlMethod
import kotlinx.coroutines.delay
import org.json.JSONException
import org.json.JSONObject

/**
 * Mock JSON [Proxy] implementation based on [MockJsonResponseReader].
 */
class StubJsonProxy(
    private val isLogNetwork: Boolean,
    private val mockReader: MockJsonResponseReader
) : Proxy<JSONObject> {

    companion object {
        private val LOGGER = getLogger(StubJsonProxy::class.java)
        private const val MOCK_ASSETS_FOLDER = "mock-response"
        private const val MOCK_REQUEST_DELAY = 600L
    }

    var responseId: String? = null

    override suspend fun send(
        method: Proxy.Method,
        urlMethod: UrlMethod,
        headers: Map<String, String>,
        params: JSONObject
    ): ProxyResult<JSONObject> {

        if (isLogNetwork) {
            LOGGER.debug(
                "Sending Mock [$method] request to '${urlMethod.getUrl()}'\n" +
                        "headers: '$headers'\n" +
                        "params: '$params'"
            )
        }

        delay(MOCK_REQUEST_DELAY)
        val mockContent = mockReader.read(MOCK_ASSETS_FOLDER, urlMethod.methodName, responseId)

        try {
            val code = mockContent.getInt("code")
            val data = mockContent.getJSONObject("data")

            return if (code in 200 until 300) {
                onSuccess(code, data)
            } else {
                onError(code, data)
            }
        } catch (e: JSONException) {
            throw IllegalArgumentException(
                "Mock content must contains code and data fields, but it doesn't. " +
                        "Mock content='$mockContent"
            )
        }
    }

    private fun onSuccess(code: Int, data: JSONObject): ProxyResult.Success<JSONObject> {
        if (isLogNetwork) {
            LOGGER.debug("Mock request success [code=${code}]: '$data'")
        }
        return ProxyResult.Success(code, data)
    }

    private fun onError(code: Int, data: JSONObject): ProxyResult.Error<JSONObject> {
        if (isLogNetwork) {
            LOGGER.error("Mock request failed [code=${code}]: '${data}'!")
        }
        // or any other exception
        val exception = VolleyError(data.optString("message", "unknown"))

        return ProxyResult.Error(code, data, exception)
    }

}