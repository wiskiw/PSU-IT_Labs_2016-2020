package com.psuteam.goodbooze.data.storage;

import android.content.SharedPreferences;

import com.psuteam.goodbooze.data.storage.reader.PropertyReader;

import org.jetbrains.annotations.NotNull;

/**
 * Методы для чтения/сохранения настроек приложения
 *
 * @author Andrey Yablonsky
 */

public class AppPreferenceStorage {

    private static final String PREF_KEY_ENDPOINT = "endpoint";
    private static final String PREF_KEY_LOG_NETWORK = "logNetwork";
    private static final String PREF_KEY_USE_STUB = "useStub";

    private SharedPreferences sharedPreferences;
    private PropertyReader propertyReader;

    /**
     * Основной конструктор
     *
     * @param sharedPreferences хранилище значений
     * @param propertyReader используется для чтения значение при отсутствии поля в SharedPreferences
     */
    public AppPreferenceStorage(SharedPreferences sharedPreferences, PropertyReader propertyReader) {
        this.sharedPreferences = sharedPreferences;
        this.propertyReader = propertyReader;
    }

    @NotNull
    public String readEndpoint() {
        return propertyReader.getString(PREF_KEY_ENDPOINT);
    }

    public boolean readIsLogNetwork() {
        return propertyReader.getBool(PREF_KEY_LOG_NETWORK);
    }

    public boolean readIsUseStub() {
        return propertyReader.getBool(PREF_KEY_USE_STUB);
    }

}
