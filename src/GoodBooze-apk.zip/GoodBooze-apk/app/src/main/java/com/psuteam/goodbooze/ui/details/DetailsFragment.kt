package com.psuteam.goodbooze.ui.details

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.content.res.AppCompatResources
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.navArgs
import androidx.recyclerview.widget.LinearLayoutManager
import com.bumptech.glide.Glide
import com.psuteam.goodbooze.R
import com.psuteam.goodbooze.app.logger.LoggerFactory
import com.psuteam.goodbooze.data.model.Comment
import com.psuteam.goodbooze.data.model.ProductDetails
import com.psuteam.goodbooze.networking.ErrorIndicator
import com.psuteam.goodbooze.networking.endpoint.request.LikeRequest
import com.psuteam.goodbooze.networking.endpoint.request.ProductDetailsRequest
import com.psuteam.goodbooze.networking.messenger.AuthedMessenger
import com.psuteam.goodbooze.networking.messenger.MessageResult
import com.psuteam.goodbooze.ui.LoggedInFragment
import com.psuteam.goodbooze.ui.ScreenUiController
import kotlinx.android.synthetic.main.fragment_details.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch


/**
 * A [Fragment] for Drinks feed screen.
 */
class DetailsFragment : LoggedInFragment() {

    companion object {
        private val LOGGER = LoggerFactory.getLogger(DetailsFragment::class.java)
    }

    private val args: DetailsFragmentArgs by navArgs()

    private lateinit var commentsAdapter: DetailsCommentsRecyclerAdapter
    private var isLiked = false

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_details, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        screenUiController.setTitle(getString(R.string.details_title))
        screenUiController.changeScreenStyle(ScreenUiController.ScreenStyle.NOT_AUTHED_FULL_SCREEN)

        commentsAdapter = DetailsCommentsRecyclerAdapter()
        commentsAdapter.clickListeners = CommentClickListener()

        commentsRecycler.layoutManager = LinearLayoutManager(context)
        commentsRecycler.adapter = commentsAdapter

        errorPanel.setRetryListener(RetryListener())


        loadDetails(args.productId)
    }

    private fun loadDetails(productId: String) {
        GlobalScope.launch(Dispatchers.Main) {

            val mockFileId = if (isLiked) "liked" else null

            val result = AuthedMessenger(app, app.getJsonProxy(mockFileId), ProductDetailsRequest(productId))
                .apply {
                    navController = super.navController
                    errorIndicator = errorPanel
                    progressIndicator = progressPanel
                }
                .send()

            if (result is MessageResult.Success) {
                bind(result.data)
            }
        }
    }

    private fun bind(productDetails: ProductDetails) {
        this.isLiked = productDetails.isLiked

        bindLikeButton(productDetails.isLiked)
        likeFab.setOnClickListener {
            sendLike(productDetails.id, !productDetails.isLiked)
        }
        likesCounterText.text = productDetails.likes.toString()

        productTitle.text = productDetails.title
        priceText.text = productDetails.price.toString()
        descriptionText.text = productDetails.description
        addressText.text = productDetails.address.name

        Glide.with(productImage.context)
            .load(productDetails.imageId)
            .centerCrop()
            .placeholder(R.drawable.ic_placeholder)
            .into(productImage)

        commentsAdapter.setItems(productDetails.comments)
    }


    private fun sendLike(productId: String, isLiked: Boolean) {
        GlobalScope.launch(Dispatchers.Main) {
            val result = AuthedMessenger(app, app.getJsonProxy(), LikeRequest(productId, isLiked))
                .apply {
                    navController = super.navController
                    progressIndicator = progressPanel
                }
                .send()

            if (result is MessageResult.Success) {
                this@DetailsFragment.isLiked = isLiked
                loadDetails(productId)
            }
        }
    }

    private fun bindLikeButton(isLiked: Boolean) {
        if (isLiked) {
            likeFab.imageTintList = AppCompatResources.getColorStateList(requireContext(), R.color.common_theme_accent_dark)
        } else {
            likeFab.imageTintList = AppCompatResources.getColorStateList(requireContext(), R.color.white)
        }
    }

    inner class RetryListener : ErrorIndicator.RetryListener {
        override fun onRetry() {

            loadDetails(args.productId)
        }
    }

    inner class CommentClickListener : DetailsCommentsRecyclerAdapter.ClickListeners {

        override fun onClick(comment: Comment) {
            val action = DetailsFragmentDirections.actionDetailsFragmentToProfileFragment(comment.userId)
            navController.navigate(action)
        }

    }

}