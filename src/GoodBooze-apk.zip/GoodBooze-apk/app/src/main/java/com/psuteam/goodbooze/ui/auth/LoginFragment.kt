package com.psuteam.goodbooze.ui.auth

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.os.bundleOf
import androidx.fragment.app.Fragment
import com.psuteam.goodbooze.R
import com.psuteam.goodbooze.ui.RootNavigationFragment
import com.psuteam.goodbooze.app.logger.LoggerFactory
import com.psuteam.goodbooze.app.utils.UiUtils
import com.psuteam.goodbooze.data.model.LoggedInUser
import com.psuteam.goodbooze.data.model.TokenPair
import com.psuteam.goodbooze.networking.endpoint.request.LoginRequest
import com.psuteam.goodbooze.networking.messenger.JsonMessenger
import com.psuteam.goodbooze.networking.messenger.MessageResult
import com.psuteam.goodbooze.ui.LoggedInActivity
import com.psuteam.goodbooze.ui.NavUtils
import com.psuteam.goodbooze.ui.ScreenUiController
import kotlinx.android.synthetic.main.fragment_login.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

/**
 * A [Fragment] for login screen.
 */
class LoginFragment : RootNavigationFragment() {

    companion object {
        private val LOGGER = LoggerFactory.getLogger(LoginFragment::class.java)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_login, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        email.afterTextChanged { onInputsChanges(it, password.text.toString()) }
        password.afterTextChanged { onInputsChanges(email.text.toString(), it) }

        login.setOnClickListener {
            UiUtils.hideKeyboard(view.context, view)
            GlobalScope.launch(Dispatchers.Main) { doAuthRequest() }
        }

        changeLoginEnable(false)
    }

    private fun onInputsChanges(login: String, password: String) {
        // ToDo: add login / password check
        val isLoginAvailable = login.isNotBlank() && password.isNotBlank()
        changeLoginEnable(isLoginAvailable)
    }

    private fun changeLoginEnable(isEnable: Boolean) {
        login.isEnabled = isEnable
    }

    private fun getInputsLogin() : String = email.text.toString().trim()
    private fun getInputsPassword() : String = password.text.toString()

    private suspend fun doAuthRequest() {
        changeLoadingState(true)
        val request = LoginRequest(getInputsLogin(), getInputsPassword())
        val result: MessageResult<LoggedInUser> = JsonMessenger(app, app.getJsonProxy(), request).send()
        changeLoadingState(false)

        when (result) {
            is MessageResult.Success<LoggedInUser> -> {
                if (result.data.getTokens().isValid()){
                    onLoginSuccess(result.data)
                } else {
                    onLoginFailed(IllegalStateException("Received expired tokens from the server!"))
                }
            }
            is MessageResult.AuthError -> onLoginFailed(result.exception)
            is MessageResult.Error -> onLoginFailed(result.exception)
        }
    }

    private fun changeLoadingState(isLoading: Boolean) {
        if (isLoading) {
            progressPanel.showProgress()
        } else {
            progressPanel.hideProgress()
        }
    }

    private fun onLoginSuccess(loggedInUser: LoggedInUser) {
        email.text?.clear()
        password.text?.clear()

        val welcomeMessage = getString(R.string.login_login_success, loggedInUser.name)
        Toast.makeText(context, welcomeMessage, Toast.LENGTH_LONG).show()

        app.dataStorageProvider.userStorage.saveLoggedInUser(loggedInUser)

        NavUtils.goToLoggedInActivity(navController, true)
    }

    private fun onLoginFailed(exception: Exception) {
        Toast.makeText(context, "Login failed! ${exception.message}", Toast.LENGTH_SHORT).show()
        LOGGER.error("Login failed!", exception)
    }

}

/**
 * Extension function to simplify setting an afterTextChanged action to EditText components.
 */
fun EditText.afterTextChanged(afterTextChanged: (String) -> Unit) {
    this.addTextChangedListener(object : TextWatcher {
        override fun afterTextChanged(editable: Editable?) {
            afterTextChanged.invoke(editable.toString())
        }

        override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {}

        override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {}
    })
}
