package com.psuteam.goodbooze.ui

import androidx.core.os.bundleOf
import androidx.navigation.NavController
import com.psuteam.goodbooze.R


object NavUtils {

    fun goToAuthActivity(navController: NavController) {
        navController.navigate(R.id.action_global_authActivity)
    }

    fun goToLoggedInActivity(navController: NavController, shouldRefreshFragment: Boolean = false) {
        val arguments = bundleOf(
            LoggedInActivity.ARG_KEY_SHOULD_REFRESH_FRAGMENT to shouldRefreshFragment
        )
        navController.navigate(R.id.action_global_loggedInActivity, arguments)
    }

}