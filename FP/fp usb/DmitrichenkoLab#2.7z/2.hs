-- Empty module to serve as the default current module.
module Hugs where
--solve1 0 =[]
--solve1 n = 2*n-1: solve1 (n-1) 
--solve n=reverse(solve1 n)

--factorial 0=1
--factorial n=n*factorial(n-1)  
--solve1 0 =[]
--solve1 n = factorial n : solve1(n-1)  
--solve n=reverse(solve1 n)


--solve:: [Double] -> Double
--solve list = if (length(list) == 1) then head(list) else (head(list) + ((solve (tail(list)) * (fromIntegral (length(list)-1)))))/fromIntegral( length(list))


--make [] = [] 
--make (x:xs) =if (x<0) then x*(-1):make xs else x : make xs 

--no:: [Double] -> Double
--no list = if (length(list) == 1) then head(list) else if (odd head(list))&&(head(list)<0) then  head(list) + no tail(list)

--no :: Integral a => [a] -> a
--no l = sum [x| x<-l, x/=0, x `mod` 2 ==1&&x<0]
--po :: Integral a => [a] -> a
--po l = -sum [x| x<-l, x/=0, x `mod` 2 ==1&&x>0]
--ne :: Integral a => [a] -> a
--ne l = multiply [x| x<-l, x/=0, x `mod` 2 ==0&&x<0]
--pe :: Integral a => [a] -> a
--pe l = sum [x| x<-l, x/=0, x `mod` 2 ==0&&x>0]


no x=if x<0&&odd x then x else 0

ne x=if x<0&&even x then x else 1

po x=if x>0&&odd x then x else 0

pe x=if x>0&&even x then x else 0


solve ::Integral a => [a] -> (a, a,a,a)
solve = foldl step (0, 1,0,0) 
  where
    step (s,p,o,i) n = (s+ (no n),p* (ne n),o-po(n),i+pe(n))