//{{NO_DEPENDENCIES}}
// ���������� ����, ��������� � Microsoft Visual C++.
// ������������ Resource.rc
//

#define IDC_STATIC                        9999
#define DLG_WIN                        101
#define IDC_EDIT1                       1002
#define IDC_EDIT2                       1003
#define IDC_EDIT3                       1004
#define IDC_EDIT4                       1005
#define IDC_EDIT5                       1006
#define IDC_EDIT6                       1007
#define IDC_EDIT7                       1008
#define IDC_SAVE                        10090
#define IDC_CANCEL                      1011

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        107
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1019
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
